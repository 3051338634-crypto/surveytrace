/* SurveyTrace · 调研证据台
   纯前端、本地处理。所有统计数字来自 core.js 的实时计算。 */
(function () {
  "use strict";

  var ST = window.ST;
  var C = window.STCharts;
  var esc = C.esc;
  var $ = function (sel) { return document.querySelector(sel); };

  var PAGE_TITLES = {
    overview: "概览",
    import: "导入数据",
    quality: "质量检查",
    explore: "探索分析",
    report: "报告"
  };

  var TYPE_LABEL = { cat: "分类", num: "数值", text: "文本", ignore: "忽略" };
  var STORAGE_KEY = "surveytrace.state.v1";

  var state = freshState();

  function freshState() {
    return {
      source: null,
      fileName: "",
      importedAt: "",
      encoding: "",
      delimiterName: "",
      skippedBlankLines: 0,
      sampleMeta: null,
      columnNotes: {},
      columns: [],
      rows: [],
      ranges: {},
      excluded: {},
      excludedNotes: {},
      log: [],
      filter: { index: null, values: [] },
      group: { index: null, target: null },
      compare: { num: null, cat: null },
      page: "overview",
      parseError: null,
      qaFilter: "all",
      qaQuery: "",
      qaLimit: 60,
      expanded: {},
      highlight: null,
      storageWarned: false
    };
  }

  /* ---------------- 基础工具 ---------------- */

  function pad(n) {
    return n < 10 ? "0" + n : String(n);
  }

  function dateTimeNow() {
    var d = new Date();
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " +
      pad(d.getHours()) + ":" + pad(d.getMinutes());
  }

  function stampNow() {
    var d = new Date();
    return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + "-" + pad(d.getHours()) + pad(d.getMinutes());
  }

  function dateOnly() {
    var d = new Date();
    return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
  }

  function downloadText(filename, text, mime) {
    var blob = new Blob([text], { type: mime || "text/plain;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1200);
  }

  function toast(message, isError) {
    var el = $("#toast");
    if (!el) return;
    el.textContent = message;
    el.className = "toast is-on" + (isError ? " is-error" : "");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(function () {
      el.className = "toast" + (isError ? " is-error" : "");
    }, 3600);
  }

  function dataReady() {
    return state.rows.length > 0 && state.columns.length > 0;
  }

  function displayName() {
    if (state.source === "sample") return "校园学习空间需求调查";
    if (state.fileName) return state.fileName.replace(/\.csv$/i, "");
    return "未命名数据集";
  }

  function typeLabel(type) {
    return TYPE_LABEL[type] || type;
  }

  function activeColumns() {
    return state.columns.filter(function (c) { return c.type !== "ignore"; });
  }

  function columnNote(index) {
    return state.columnNotes[index] || "";
  }

  function columnLabel(col) {
    if (!col) return "";
    return col.label ? col.label : col.name;
  }

  function ensureCompare() {
    if (!state.compare) state.compare = { num: null, cat: null };
    var nums = state.columns.filter(function (c) { return c.type === "num"; });
    var cats = state.columns.filter(function (c) { return c.type === "cat"; });
    if (state.compare.num === null || state.compare.num === undefined ||
        !state.columns[state.compare.num] || state.columns[state.compare.num].type !== "num") {
      state.compare.num = nums.length ? nums[0].index : null;
    }
    if (state.compare.cat === null || state.compare.cat === undefined ||
        !state.columns[state.compare.cat] || state.columns[state.compare.cat].type !== "cat") {
      state.compare.cat = cats.length ? cats[0].index : null;
    }
  }

  /* ---------------- 状态持久化 ---------------- */

  function save() {
    try {
      var payload = JSON.stringify({
        v: 1,
        source: state.source,
        fileName: state.fileName,
        importedAt: state.importedAt,
        encoding: state.encoding,
        delimiterName: state.delimiterName,
        skippedBlankLines: state.skippedBlankLines,
        sampleMeta: state.sampleMeta,
        columnNotes: state.columnNotes,
        columns: state.columns,
        rows: state.rows,
        ranges: state.ranges,
        excluded: state.excluded,
        excludedNotes: state.excludedNotes,
        log: state.log.slice(-200),
        filter: state.filter,
        group: state.group,
        compare: state.compare,
        page: state.page,
        parseError: state.parseError,
        qaFilter: state.qaFilter,
        qaQuery: state.qaQuery,
        qaLimit: state.qaLimit
      });
      if (payload.length > 3.2 * 1024 * 1024) throw new Error("too large");
      localStorage.setItem(STORAGE_KEY, payload);
    } catch (err) {
      if (!state.storageWarned) {
        state.storageWarned = true;
        if (dataReady()) {
          toast("数据量较大，浏览器本地存储未能写入：本次会话可正常使用，刷新后需重新导入。", true);
        }
      }
    }
  }

  function restore() {
    var raw;
    try { raw = localStorage.getItem(STORAGE_KEY); } catch (e) { return; }
    if (!raw) return;
    try {
      var saved = JSON.parse(raw);
      if (!saved || saved.v !== 1) return;
      var restored = freshState();
      [
        "source", "fileName", "importedAt", "encoding", "delimiterName", "skippedBlankLines",
        "sampleMeta", "columnNotes", "columns", "rows", "ranges", "excluded", "excludedNotes",
        "log", "filter", "group", "compare", "parseError", "qaFilter", "qaQuery", "qaLimit"
      ].forEach(function (key) {
        if (saved[key] !== undefined && saved[key] !== null) restored[key] = saved[key];
      });
      restored.page = PAGE_TITLES[saved.page] ? saved.page : "overview";
      restored.storageWarned = true;
      state = restored;
      if (!state.excluded) state.excluded = {};
      if (!state.excludedNotes) state.excludedNotes = {};
      if (!state.log) state.log = [];
      if (!state.ranges) state.ranges = {};
      if (!state.columnNotes) state.columnNotes = {};
      if (!state.filter) state.filter = { index: null, values: [] };
      if (!state.group) state.group = { index: null, target: null };
      if (!state.compare) state.compare = { num: null, cat: null };
    } catch (e) {
      /* 忽略损坏的本地状态 */
    }
  }

  /* ---------------- 数据装载 ---------------- */

  function defaultSelections() {
    var cat = state.columns.filter(function (c) { return c.type === "cat"; })[0];
    var num = state.columns.filter(function (c) { return c.type === "num"; })[0];
    state.filter = { index: null, values: [] };
    state.group = { index: cat ? cat.index : null, target: null };
    var candidate = num || cat;
    if (candidate && cat && candidate.index === cat.index) {
      var other = state.columns.filter(function (c) { return c.type === "cat" && c.index !== cat.index; })[0];
      candidate = other || null;
    }
    state.group.target = candidate ? candidate.index : null;
    ensureCompare();
  }

  function applyDataset(parsed, opts) {
    var cols = ST.inferColumns(parsed.header, parsed.rows);
    var notes = {};
    var ranges = {};

    if (opts.meta && opts.meta.columns) {
      opts.meta.columns.forEach(function (meta) {
        var idx = parsed.header.indexOf(meta.name);
        if (idx < 0) return;
        if (meta.note) notes[idx] = meta.note;
        if (meta.label) cols[idx].label = meta.label;
        if (meta.range) ranges[idx] = { min: meta.range.min, max: meta.range.max };
        if (meta.name === "respondent_id") {
          cols[idx].type = "ignore";
          cols[idx].isId = true;
        }
      });
    }

    state.source = opts.source;
    state.fileName = opts.fileName || "";
    state.encoding = opts.encoding || "";
    state.delimiterName = opts.delimiterName || parsed.delimiterName;
    state.skippedBlankLines = parsed.skippedBlankLines || 0;
    state.sampleMeta = opts.meta || null;
    state.columnNotes = notes;
    state.columns = cols;
    state.rows = parsed.rows;
    state.ranges = ranges;
    state.excluded = {};
    state.excludedNotes = {};
    state.log = [];
    state.parseError = null;
    state.qaFilter = "all";
    state.qaQuery = "";
    state.qaLimit = 60;
    state.expanded = {};
    state.highlight = null;
    state.importedAt = dateTimeNow();
    state.storageWarned = false;
    defaultSelections();
  }

  function clearDataset() {
    var page = state.page;
    var kept = freshState();
    kept.page = page;
    state = kept;
    save();
    render();
    toast("已清空数据与排除记录");
  }

  function loadSample(fromUser) {
    var sample = window.SURVEYTRACE_SAMPLE;
    if (!sample) {
      toast("示例数据文件未加载，请检查 assets/sample-data.js", true);
      return;
    }
    try {
      var parsed = ST.parseCSV(sample.csv);
      applyDataset(parsed, {
        source: "sample",
        fileName: sample.file,
        meta: sample,
        encoding: "UTF-8（文件内嵌）",
        delimiterName: parsed.delimiterName
      });
      state.page = "overview";
      save();
      render();
      toast("已载入 120 行合成演示数据，可在质量检查中查看提示");
      if (fromUser) window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      toast("示例数据载入失败：" + err.message, true);
    }
  }

  function failImport(err, fileName) {
    var page = state.page;
    var kept = freshState();
    kept.page = "import";
    kept.parseError = {
      fileName: fileName || "未命名文件",
      message: err && err.message ? err.message : "未知解析错误",
      line: err && err.line ? err.line : 0,
      at: dateTimeNow()
    };
    state = kept;
    save();
    render();
    toast("CSV 解析失败：" + (err && err.message ? err.message : "无法解析"), true);
  }

  function handleFile(file) {
    if (!file) return;
    if (file.size > ST.LIMITS.maxBytes) {
      failImport(new Error("文件大小 " + ST.fmt(file.size / 1024 / 1024, 2) + " MB，超过 5 MB 上限。请先精简或抽样后再导入。"), file.name);
      return;
    }
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var decoded = ST.decodeBuffer(reader.result);
        var parsed = ST.parseCSV(decoded.text);
        var encodingLabel = decoded.encoding + (decoded.bom ? " · " + decoded.bom : "") + "（自动识别）";
        applyDataset(parsed, {
          source: "import",
          fileName: file.name,
          encoding: encodingLabel,
          delimiterName: parsed.delimiterName,
          skipped: parsed.skippedBlankLines
        });
        state.page = "import";
        save();
        render();
        window.scrollTo({ top: 0, behavior: "smooth" });
        toast("已解析 " + parsed.rows.length + " 行 × " + parsed.header.length + " 列。请确认字段类型。");
      } catch (err) {
        failImport(err, file.name);
      }
    };
    reader.onerror = function () {
      failImport(new Error("浏览器读取文件失败，可能是文件被占用或已损坏。"), file.name);
    };
    reader.readAsArrayBuffer(file);
  }

  /* ---------------- 样本范围 ---------------- */

  function scope() {
    var sampleRows = state.rows.filter(function (r) { return !state.excluded[r.n]; });
    var rows = sampleRows;
    var filterText = "无筛选";
    var fi = state.filter.index;
    if (fi !== null && fi !== undefined && state.columns[fi] && state.filter.values.length) {
      var set = new Set(state.filter.values);
      rows = rows.filter(function (r) { return set.has(ST.norm(r.cells[fi])); });
      filterText = state.columns[fi].name + " = " + state.filter.values.join("、");
    }
    return {
      rows: rows,
      sampleRows: sampleRows,
      total: state.rows.length,
      excludedCount: state.rows.length - sampleRows.length,
      filterText: filterText,
      filterIndex: fi
    };
  }

  function qaAll() {
    return ST.buildQA(state.rows, state.columns, state.ranges);
  }

  /* ---------------- 通用组件 ---------------- */

  function pageHead(no, title, desc, actions) {
    return '' +
      '<div class="page-head">' +
      '<div><div class="eyebrow">' + no + " / " + esc(title) + "</div>" +
      "<h1>" + esc(title) + "</h1>" +
      '<p class="page-desc">' + desc + "</p></div>" +
      (actions ? '<div class="page-actions">' + actions + "</div>" : "") +
      "</div>";
  }

  function bannerHtml() {
    if (state.source === "sample") {
      return '' +
        '<div class="banner banner-synthetic">' +
        '<span class="banner-icon">!</span>' +
        "<div><strong>合成演示数据，不是真实调研。</strong> " +
        "内置 120 行匿名数据由程序按固定随机种子生成，包含少量缺失、完全重复与异常数值，仅用于演示流程。" +
        '<div class="banner-actions">' +
        '<button class="btn btn-sm btn-warn" data-action="download-sample">下载示例 CSV</button>' +
        '<button class="btn btn-sm btn-secondary" data-action="pick-file">换成我的 CSV</button>' +
        "</div></div></div>";
    }
    if (state.source === "import") {
      return '' +
        '<div class="banner banner-info">' +
        '<span class="banner-icon">i</span>' +
        "<div><strong>数据来自本地文件：</strong>" + esc(state.fileName) +
        "。CSV 在浏览器内解析，原始问卷内容不会上传到任何服务器。" +
        '<div class="banner-actions"><button class="btn btn-sm btn-ghost" data-action="pick-file">重新导入</button></div>' +
        "</div></div>";
    }
    return "";
  }

  function emptyState(title, desc, actions) {
    return '' +
      '<div class="empty">' +
      '<div class="empty-icon">' + iconSvg("table") + "</div>" +
      "<h3>" + esc(title) + "</h3>" +
      "<p>" + esc(desc) + "</p>" +
      '<div class="chip-row" style="justify-content:center">' + actions + "</div>" +
      "</div>";
  }

  function iconSvg(name) {
    var paths = {
      table: '<path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M8 6v12M16 6v12" stroke="currentColor" stroke-width="1.2" opacity=".55"/>',
      upload: '<path d="M12 16V5m0 0l-4 4m4-4l4 4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 17v2a1 1 0 001 1h12a1 1 0 001-1v-2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
      shield: '<path d="M12 3l7 3v6c0 4.2-2.9 7.4-7 9-4.1-1.6-7-4.8-7-9V6l7-3z" stroke="currentColor" stroke-width="1.5"/><path d="M9 12l2 2 4-4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>'
    };
    return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">' + (paths[name] || paths.table) + "</svg>";
  }

  function kpi(label, value, note, cls) {
    return '' +
      '<div class="kpi ' + (cls || "") + '">' +
      '<div class="kpi-label">' + esc(label) + "</div>" +
      '<div class="kpi-value">' + value + "</div>" +
      (note ? '<div class="kpi-note">' + note + "</div>" : "") +
      "</div>";
  }

  function metaChips(base, missing, valid, extra) {
    return '' +
      '<div class="meta-row">' +
      '<span class="chip chip-muted">分母：' + esc(base) + "</span>" +
      '<span class="chip chip-muted">缺失：' + esc(missing) + "</span>" +
      '<span class="chip chip-teal">有效样本：' + esc(valid) + "</span>" +
      (extra ? '<span class="chip">' + extra + "</span>" : "") +
      "</div>";
  }

  function insightCard(ins, index) {
    return '' +
      '<article class="insight">' +
      '<div class="insight-top"><span class="insight-kicker">' + esc(ins.kicker) + "</span>" +
      '<span class="insight-index">事实 ' + pad(index + 1) + "</span></div>" +
      "<h3>" + esc(ins.title) + "</h3>" +
      '<p class="insight-text">' + esc(ins.statement) + "</p>" +
      evidenceHtml(ins.evidence) +
      "</article>";
  }

  function evidenceHtml(ev) {
    var denomCount = ev.rows.length;
    var numCount = ev.numeratorRows.length;
    var showNumerator = numCount && numCount !== denomCount;

    var detail = "";
    if (ev.detailRows.length) {
      var shown = ev.detailRows.slice(0, 200);
      var head = '<tr><th class="num">原始行号</th>' + ev.detailColumns.map(function (name) {
        return "<th>" + esc(name) + "</th>";
      }).join("") + "</tr>";
      var body = shown.map(function (row) {
        return '<tr><td class="num rowno"><button class="btn btn-ghost btn-xs" data-action="goto-row" data-n="' + row.n + '">' + row.n + "</button></td>" +
          row.values.map(function (v) {
            return '<td class="cell-clip" title="' + esc(v) + '">' + esc(v || "（空）") + "</td>";
          }).join("") + "</tr>";
      }).join("");
      detail = '<div class="table-wrap"><table class="data-table">' + head + body + "</table></div>" +
        '<div class="evidence-note">' + (ev.detailRows.length > 200
          ? "明细共 " + ST.fmtInt(ev.detailRows.length) + " 行，此处显示前 200 行；行号列表已覆盖全部参与行。"
          : "上表逐行列出参与计算的有效记录。") + "</div>";
    }

    return '' +
      '<details class="evidence">' +
      "<summary>查看依据 <span class=\"evidence-hint\">字段 · 筛选 · 计算方式 · 原始行号</span></summary>" +
      '<div class="evidence-body">' +
      '<dl class="evidence-grid">' +
      '<div class="evidence-item"><dt>字段</dt><dd>' + esc(ev.field) + "</dd></div>" +
      '<div class="evidence-item"><dt>筛选条件</dt><dd>' + esc(ev.filter) + "</dd></div>" +
      '<div class="evidence-item"><dt>计算方式</dt><dd>' + esc(ev.method) + "</dd></div>" +
      '<div class="evidence-item"><dt>分母</dt><dd>' + esc(ev.denominator) + "</dd></div>" +
      '<div class="evidence-item"><dt>分子</dt><dd>' + esc(ev.numerator) + "</dd></div>" +
      '<div class="evidence-item"><dt>参与行数</dt><dd>' + ST.fmtInt(denomCount) + " 行" +
      (showNumerator ? "；其中分子 " + ST.fmtInt(numCount) + " 行" : "") + "</dd></div>" +
      "</dl>" +
      '<div class="evidence-item"><dt>分母行号（原始 CSV 数据行，表头不计）</dt><div class="rownum-block">' +
      esc(ST.compressRanges(ev.rows)) + "</div></div>" +
      (showNumerator
        ? '<div class="evidence-item" style="margin-top:8px"><dt>分子行号（命中该取值 / 全部有效数值行）</dt><div class="rownum-block">' +
          esc(ST.compressRanges(ev.numeratorRows)) + "</div></div>"
        : "") +
      detail +
      "</div></details>";
  }

  /* ---------------- 概览 ---------------- */

  function renderOverview() {
    if (!dataReady()) {
      return '' +
        pageHead("01", "概览", "把问卷数据变成可核查的结论：每个数字都能追到原始行，每次样本排除都能撤销。", "") +
        '<section class="hero">' +
        '<div class="hero-copy">' +
        '<span class="hero-eyebrow">本地数据工作台 · 无登录</span>' +
        "<h2>每一个数字，<br>都能回到<em>原始那一行</em>。</h2>" +
        "<p>导入问卷 CSV，SurveyTrace 会逐行标注缺失、完全重复与非法数值；你可以保留或排除任意一条样本，统计与报告会同步重算，并保留完整的操作记录。</p>" +
        '<div class="hero-actions">' +
        '<button class="btn btn-primary" data-action="load-sample">体验示例（120 行）</button>' +
        '<button class="btn btn-secondary" data-action="pick-file">导入 CSV 文件</button>' +
        "</div>" +
        '<p class="hero-note"><span>CSV 只在浏览器内解析</span><span>不登录 · 不付费</span><span>不上传问卷内容</span></p>' +
        "</div>" +
        '<div class="hero-panel" aria-hidden="true">' +
        '<div class="trace-card"><div class="lbl">结论 · 图书馆是首选空间</div><div class="num">36.5%</div>' +
        '<div class="trace-rows"><span>12</span><span class="hit">31</span><span>44</span><span class="hit">52</span><span>77</span><span class="hit">90</span></div></div>' +
        '<div class="trace-link"></div>' +
        '<div class="trace-card"><div class="lbl">依据 · 有效回答 118 条</div>' +
        '<div class="small muted">字段：prefer_space　筛选：无</div>' +
        '<div class="trace-rows"><span>缺失 2</span><span>排除 0</span><span>行号可点开</span></div></div>' +
        "</div>" +
        "</section>" +
        '<div class="feature-grid">' +
        '<div class="feature"><div class="fnum">01 / TRACE</div><h3>结论可追溯</h3><p>每张洞察卡片都能展开字段、筛选条件、计算方式与参与计算的原始行号，报告与原始数据之间没有黑箱。</p></div>' +
        '<div class="feature"><div class="fnum">02 / UNDO</div><h3>排除可撤销</h3><p>默认保留全部样本。排除某一行后，统计与报告立即重算；随时可以恢复，并保留每一次操作记录。</p></div>' +
        '<div class="feature"><div class="fnum">03 / LOCAL</div><h3>数据留在本地</h3><p>CSV 由浏览器本地解析和计算，不上传服务器、不需要登录，也不依赖任何模型服务。</p></div>' +
        "</div>";
    }

    var sc = scope();
    var qa = qaAll();
    var summary = ST.qaSummary(qa);
    var cols = state.columns;
    var catCount = cols.filter(function (c) { return c.type === "cat"; }).length;
    var numCount = cols.filter(function (c) { return c.type === "num"; }).length;
    var textCount = cols.filter(function (c) { return c.type === "text"; }).length;
    var ignoreCount = cols.filter(function (c) { return c.type === "ignore"; }).length;
    var insights = ST.buildInsights({
      rows: sc.rows,
      columns: cols,
      totalRows: state.rows.length,
      excludedCount: sc.excludedCount,
      filterText: sc.filterText
    });

    return '' +
      pageHead("01", "概览", "当前数据的状态、样本口径与关键事实。所有数字由程序根据当前样本实时计算。",
        '<button class="btn btn-secondary" data-action="pick-file">导入 CSV</button>' +
        '<button class="btn btn-primary" data-action="go-explore">开始探索</button>') +
      bannerHtml() +
      '<div class="kpi-grid">' +
      kpi("原始行数", ST.fmtInt(state.rows.length), "导入时的全部记录", "is-accent") +
      kpi("当前样本", ST.fmtInt(sc.sampleRows.length), "已排除 " + ST.fmtInt(sc.excludedCount) + " 行", "") +
      kpi("分析字段", ST.fmtInt(activeColumns().length), "分类 " + catCount + " · 数值 " + numCount + " · 文本 " + textCount, "") +
      kpi("有提示行", ST.fmtInt(summary.flaggedRows), "按原始行去重；不等同作弊", "is-warn") +
      "</div>" +
      '<div class="section">' +
      '<div class="source-strip">' +
      "<div><div class=\"source-name\">" + esc(displayName()) +
      ' <span class="chip ' + (state.source === "sample" ? "chip-amber" : "chip-teal") + '">' +
      (state.source === "sample" ? "合成演示数据" : "本地导入") + "</span></div>" +
      '<div class="source-meta">' +
      "<span>文件：<b>" + esc(state.fileName || "内嵌示例") + "</b></span>" +
      "<span>编码：<b>" + esc(state.encoding || "—") + "</b></span>" +
      "<span>分隔符：<b>" + esc(state.delimiterName || "—") + "</b></span>" +
      "<span>载入时间：<b>" + esc(state.importedAt) + "</b></span>" +
      "</div></div>" +
      '<div class="source-actions">' +
      (state.source === "sample" ? '<button class="btn btn-sm btn-secondary" data-action="download-sample">下载示例 CSV</button>' : "") +
      '<button class="btn btn-sm btn-ghost" data-action="go-import">查看数据</button>' +
      "</div></div>" +
      "</div>" +
      '<div class="section grid-2">' +
      '<div class="card"><div class="card-head"><div><h2 class="card-title">质检摘要</h2>' +
      '<p class="card-sub">缺失、完全重复与非法数值按行标注；异常提示不代表造假或作弊。</p></div>' +
      '<button class="btn btn-sm btn-secondary" data-action="go-quality">查看全部</button></div>' +
      '<div class="chip-row">' +
      '<span class="chip chip-amber">缺失 ' + ST.fmtInt(summary.missingRows) + " 行</span>" +
      '<span class="chip chip-navy">完全重复 ' + ST.fmtInt(summary.duplicateRows) + " 行</span>" +
      '<span class="chip chip-danger">非法数值 ' + ST.fmtInt(summary.invalidRows) + " 行</span>" +
      '<span class="chip chip-muted">超范围 ' + ST.fmtInt(summary.rangeRows) + " 行</span>" +
      "</div>" +
      '<div class="card-foot"><span>已排除 ' + ST.fmtInt(sc.excludedCount) + " 行</span><span>操作记录 " +
      ST.fmtInt(state.log.length) + " 条</span><span>全部可撤销</span></div></div>" +
      '<div class="card"><div class="card-head"><div><h2 class="card-title">字段结构</h2>' +
      '<p class="card-sub">分类用于频数与分组，数值用于均值与中位数，文本与忽略字段不参与数值统计。</p></div></div>' +
      '<div class="chip-row" style="margin-bottom:10px">' +
      '<span class="chip chip-teal">分类 ' + catCount + "</span>" +
      '<span class="chip chip-teal">数值 ' + numCount + "</span>" +
      '<span class="chip chip-muted">文本 ' + textCount + "</span>" +
      '<span class="chip chip-muted">忽略 ' + ignoreCount + "</span>" +
      "</div>" +
      '<div class="small muted">' +
      (cols.filter(function (c) { return c.type === "ignore"; }).map(function (c) {
        return esc(c.name) + (c.isId ? "（ID，不参与均值）" : "");
      }).join("、") || "没有忽略字段") +
      "。" +
      (cols.some(function (c) { return c.isId; }) ? " ID 字段仅用于定位原始行，不参与均值、占比等统计。" : "") +
      "</div>" +
      '<div class="card-foot"><span>可随时在导入页调整字段类型</span></div></div>' +
      "</div>" +
      '<div class="section">' +
      '<div class="section-head"><h2 class="section-title">关键事实</h2>' +
      '<p class="section-sub">每条结论都可展开依据；当前筛选：' + esc(sc.filterText) + "</p></div>" +
      '<div class="insight-list">' + insights.slice(0, 3).map(insightCard).join("") + "</div>" +
      "</div>" +
      '<div class="section grid-3">' +
      '<a class="card" href="#" data-action="go-quality" style="text-decoration:none;color:inherit">' +
      '<div class="eyebrow">下一步 01</div><h3 class="card-title">核对数据质量</h3>' +
      '<p class="card-sub">逐行查看缺失、重复与非法数值，按需排除并保留记录。</p></a>' +
      '<a class="card" href="#" data-action="go-explore" style="text-decoration:none;color:inherit">' +
      '<div class="eyebrow">下一步 02</div><h3 class="card-title">探索与分组</h3>' +
      '<p class="card-sub">频数、百分比、均值、中位数，以及一个分类字段的分组对比。</p></a>' +
      '<a class="card" href="#" data-action="go-report" style="text-decoration:none;color:inherit">' +
      '<div class="eyebrow">下一步 03</div><h3 class="card-title">生成报告</h3>' +
      '<p class="card-sub">事实摘要、图表、样本口径、排除记录与局限说明，可导出 HTML 与 CSV。</p></a>' +
      "</div>";
  }

  /* ---------------- 导入 ---------------- */

  function renderImport() {
    var head = pageHead("02", "导入数据",
      "CSV 在浏览器本地解析，支持 UTF-8 / BOM、中文、引号与逗号。解析失败会给出具体原因，并清空旧数据，避免误读。",
      dataReady()
        ? '<button class="btn btn-secondary" data-action="go-quality">前往质量检查</button>'
        : '<button class="btn btn-secondary" data-action="load-sample">体验示例数据</button>');

    var limits = '' +
      '<div class="card"><div class="card-head"><div><h2 class="card-title">数据限制与处理方式</h2>' +
      '<p class="card-sub">这些限制在解析前生效；超出会直接拒绝并说明原因。</p></div></div>' +
      '<div class="chip-row">' +
      '<span class="chip chip-navy">最多 3,000 行数据</span>' +
      '<span class="chip chip-navy">最多 40 列</span>' +
      '<span class="chip chip-navy">单文件 ≤ 5 MB</span>' +
      '<span class="chip chip-teal">UTF-8 / UTF-16 / GB18030 自动识别</span>' +
      '<span class="chip chip-muted">逗号 / 分号 / 制表符自动检测</span>' +
      "</div>" +
      '<div class="card-foot"><span>文件不会离开本机</span><span>解析使用 TextDecoder 与自建 CSV 状态机</span><span>表头必须有名称</span></div></div>';

    var errorHtml = "";
    if (state.parseError) {
      errorHtml = '<div class="card" style="border-color:#ecc6c1">' +
        '<div class="card-head"><div><h2 class="card-title danger-text">无法解析：' + esc(state.parseError.fileName) + "</h2>" +
        '<p class="card-sub">解析在第 ' + (state.parseError.line || "?") + " 行附近停止。为避免误读，之前载入的数据已清空。</p></div>" +
        '<span class="chip chip-danger">解析失败</span></div>' +
        '<div class="banner banner-error" style="margin:0 0 12px"><span class="banner-icon">×</span><div><strong>具体原因：</strong>' +
        esc(state.parseError.message) + "</div></div>" +
        '<div class="small" style="color:var(--ink-2)"><b>可以这样修复：</b></div>' +
        '<ul class="small muted" style="margin:6px 0 14px;padding-left:20px;line-height:1.9">' +
        "<li>字段之间用英文逗号分隔；字段内容里出现逗号时，用英文双引号包裹整个字段。</li>" +
        "<li>检查每条记录的列数是否与表头一致，常见原因是漏写或多写了一个逗号。</li>" +
        "<li>引号必须成对；字段里的引号写成两个英文双引号（&quot;&quot;）表示一个引号。</li>" +
        "<li>用表格软件另存为“CSV UTF-8（逗号分隔）”，避免编码错误。</li>" +
        "<li>行数 ≤ 3,000、列数 ≤ 40、文件 ≤ 5 MB。</li>" +
        "</ul>" +
        '<div class="chip-row"><button class="btn btn-primary btn-sm" data-action="pick-file">重新选择文件</button>' +
        '<button class="btn btn-secondary btn-sm" data-action="load-sample">先载入示例数据</button></div>' +
        "</div>";
    }

    var dropzone = '' +
      '<div class="dropzone" id="dropzone">' +
      '<div class="dropzone-icon">' + iconSvg("upload") + "</div>" +
      "<h3>把 CSV 拖到这里，或点击选择文件</h3>" +
      "<p>第一行作为表头。支持中文列名、带引号的逗号字段与多行文本。</p>" +
      '<button class="btn btn-primary" data-action="pick-file">选择 CSV 文件</button> ' +
      '<button class="btn btn-secondary" data-action="load-sample">体验示例（120 行）</button>' +
      '<div class="limit-row">' +
      '<span class="chip">≤ 3,000 行</span><span class="chip">≤ 40 列</span><span class="chip">≤ 5 MB</span>' +
      "</div>" +
      '<div class="hint">解析与统计全部在浏览器内完成；刷新后数据仍保存在本机浏览器（受本地存储容量限制）。</div>' +
      "</div>";

    var current = "";
    if (!dataReady()) {
      return head + limits + (errorHtml ? '<div class="section">' + errorHtml + "</div>" : "") +
        '<div class="section">' + dropzone + "</div>" +
        '<div class="section">' + emptyState("还没有载入数据",
          "可以先体验 120 行合成示例，或直接导入你自己的 CSV。",
          '<button class="btn btn-primary" data-action="load-sample">载入示例数据</button>' +
          '<button class="btn btn-secondary" data-action="pick-file">导入 CSV</button>') +
        "</div>";
    }

    var parsedInfo = '<div class="parse-summary">' +
      '<span class="chip chip-teal">解析成功</span>' +
      "<span>数据行 <b>" + ST.fmtInt(state.rows.length) + "</b></span>" +
      "<span>列 <b>" + ST.fmtInt(state.columns.length) + "</b></span>" +
      "<span>编码 <b>" + esc(state.encoding) + "</b></span>" +
      "<span>分隔符 <b>" + esc(state.delimiterName) + "</b></span>" +
      "<span>载入 <b>" + esc(state.importedAt) + "</b></span>" +
      (state.skippedBlankLines ? "<span>已跳过空行 <b>" + state.skippedBlankLines + "</b></span>" : "") +
      "</div>";

    var previewHead = '<tr><th class="num">#</th>' + state.columns.map(function (c) {
      return '<th title="' + esc(c.name) + '">' + esc(c.name) + "</th>";
    }).join("") + "</tr>";
    var previewBody = state.rows.slice(0, 20).map(function (row) {
      return '<tr><td class="num rowno">' + row.n + "</td>" +
        row.cells.map(function (v) {
          return '<td class="cell-clip" title="' + esc(v) + '">' + esc(v || "—") + "</td>";
        }).join("") + "</tr>";
    }).join("");

    var preview = '<div class="card"><div class="card-head"><div><h2 class="card-title">数据预览</h2>' +
      '<p class="card-sub">显示前 20 行；表格可横向滚动。空单元格已保留为空，不自动填补。</p></div>' +
      '<span class="chip chip-muted">共 ' + ST.fmtInt(state.rows.length) + " 行 × " + state.columns.length + " 列</span></div>" +
      '<div class="table-wrap"><table class="data-table">' + previewHead + previewBody + "</table></div>" +
      '<div class="card-foot"><span>行号为原始数据行序（表头不计）</span><span>下拉可查看全部字段</span></div></div>';

    var fieldHead = '<tr><th class="num">#</th><th>字段</th><th class="num">唯一值</th><th class="num">缺失</th><th>示例值</th><th>类型</th><th>合理范围（数值）</th></tr>';
    var fieldBody = state.columns.map(function (col) {
      var options = ["cat", "num", "text", "ignore"].map(function (t) {
        return '<option value="' + t + '"' + (col.type === t ? " selected" : "") + ">" + TYPE_LABEL[t] + "</option>";
      }).join("");
      var range = state.ranges[col.index] || {};
      var rangeHtml = col.type === "num"
        ? '<div class="range-inputs"><input type="number" placeholder="不限" value="' +
          (range.min === undefined || range.min === null ? "" : range.min) + '" data-change="range-min" data-index="' + col.index + '" aria-label="最小值">' +
          "<span>–</span>" +
          '<input type="number" placeholder="不限" value="' + (range.max === undefined || range.max === null ? "" : range.max) +
          '" data-change="range-max" data-index="' + col.index + '" aria-label="最大值"></div>'
        : '<span class="muted small">—</span>';

      return "<tr>" +
        '<td class="num rowno">' + (col.index + 1) + "</td>" +
        '<td><div class="field-name">' + esc(columnLabel(col)) +
        (columnLabel(col) !== col.name ? '<span class="field-orig">' + esc(col.name) + "</span>" : "") +
        (col.isId ? ' <span class="badge badge-id">ID · 不参与均值</span>' : "") + "</div>" +
        (columnNote(col.index) ? '<div class="field-note">' + esc(columnNote(col.index)) + "</div>" : "") +
        "</td>" +
        '<td class="num tnum">' + ST.fmtInt(col.uniqueCount) + "</td>" +
        '<td class="num tnum">' + ST.fmtInt(col.missingCount) + "</td>" +
        '<td class="small muted cell-clip" title="' + esc(col.sampleValues.join(" / ")) + '">' +
        (esc(col.sampleValues.join(" / ")) || "（空）") + "</td>" +
        '<td><select class="select" data-change="set-type" data-index="' + col.index + '"' +
        (col.isId ? ' disabled title="ID 字段固定不参与统计"' : "") + ">" + options + "</select>" +
        (col.isId ? '<div class="small muted" style="margin-top:3px">ID 固定为忽略</div>' : "") + "</td>" +
        "<td>" + rangeHtml + "</td>" +
        "</tr>";
    }).join("");

    var fields = '<div class="card"><div class="card-head"><div><h2 class="card-title">字段类型确认</h2>' +
      '<p class="card-sub">自动推断后仍可手动调整。分类用于频数与分组；数值用于均值、中位数与分布；文本与忽略字段不进入数值统计。</p></div>' +
      '<span class="chip chip-teal">' + activeColumns().length + " 个字段参与分析</span></div>" +
      '<div class="table-wrap"><table class="data-table field-table">' + fieldHead + fieldBody + "</table></div>" +
      '<div class="card-foot"><button class="btn btn-primary btn-sm" data-action="go-quality">使用当前字段设置，进入质量检查</button>' +
      "<span>修改会立即生效，并同步所有统计与报告</span></div></div>";

    current = parsedInfo + preview + fields;

    return head + bannerHtml() + (errorHtml ? '<div class="section">' + errorHtml + "</div>" : "") +
      '<div class="section grid-2">' + limits +
      '<div class="card"><div class="card-head"><div><h2 class="card-title">替换数据</h2>' +
      '<p class="card-sub">重新导入会清空当前的字段设置、排除记录与操作日志。</p></div></div>' +
      '<div class="dropzone" style="padding:22px 14px">' +
      '<div class="dropzone-icon" style="width:34px;height:34px">' + iconSvg("upload") + "</div>" +
      "<h3>拖入或选择新的 CSV</h3><p>当前数据不会被自动合并。</p>" +
      '<button class="btn btn-secondary btn-sm" data-action="pick-file">选择文件</button>' +
      "</div></div></div>" +
      '<div class="section">' + current + "</div>";
  }

  /* ---------------- 质量检查 ---------------- */

  function issueKind(issue) {
    return issue.kind;
  }

  function qaMatches(item) {
    var f = state.qaFilter;
    var q = state.qaQuery.trim();
    if (q) {
      var hitText = String(item.n) === q || String(item.n).indexOf(q) === 0 ||
        item.issues.some(function (it) { return it.text.indexOf(q) >= 0; });
      if (!hitText) return false;
    }
    if (f === "all") return true;
    if (f === "excluded") return !!state.excluded[item.n];
    if (f === "flagged") return item.issues.length > 0;
    return item.issues.some(function (it) { return issueKind(it) === f; });
  }

  function renderQuality() {
    if (!dataReady()) {
      return pageHead("03", "质量检查", "逐行查看缺失、完全重复与非法数值，并按需排除样本。", "") +
        emptyState("还没有可检查的数据", "先导入 CSV 或载入示例数据，再进行逐行质检。",
          '<button class="btn btn-primary" data-action="load-sample">载入示例数据</button>' +
          '<button class="btn btn-secondary" data-action="pick-file">导入 CSV</button>');
    }

    var qa = qaAll();
    var summary = ST.qaSummary(qa);
    var sc = scope();
    var filtered = qa.filter(qaMatches);
    var visible = filtered.slice(0, state.qaLimit);

    var filterDefs = [
      { key: "all", label: "全部", count: qa.length },
      { key: "flagged", label: "有提示", count: summary.flaggedRows },
      { key: "missing", label: "缺失", count: summary.missingRows },
      { key: "duplicate", label: "完全重复", count: summary.duplicateRows },
      { key: "invalid", label: "非法数值", count: summary.invalidRows },
      { key: "range", label: "超范围", count: summary.rangeRows },
      { key: "excluded", label: "已排除", count: sc.excludedCount }
    ];

    var filterHtml = filterDefs.map(function (def) {
      return '<button class="chip-btn' + (state.qaFilter === def.key ? " is-on" : "") +
        '" data-action="qa-filter" data-filter="' + def.key + '">' + def.label +
        " <span style=\"opacity:.65\">" + ST.fmtInt(def.count) + "</span></button>";
    }).join("");

    var rows = visible.map(function (item) {
      var excluded = !!state.excluded[item.n];
      var issueHtml = item.issues.length
        ? '<div class="issue-list">' + item.issues.map(function (it) {
          return '<span class="issue issue-' + it.kind + '">' + esc(it.text) + "</span>";
        }).join("") + "</div>"
        : '<span class="chip chip-teal">无明显提示</span>';

      var action = excluded
        ? '<button class="btn btn-secondary btn-xs" data-action="restore-row" data-n="' + item.n + '">恢复</button>'
        : '<button class="btn btn-warn btn-xs" data-action="exclude-row" data-n="' + item.n +
          '" data-note="' + esc((item.issues[0] && item.issues[0].text) || "手动排除") + '">排除</button>';

      var detailRow = "";
      if (state.expanded[item.n]) {
        var detailCells = state.columns.map(function (col) {
          return "<div><dt>" + esc(columnLabel(col)) + "</dt><dd>" + (esc(state.rows[item.n - 1].cells[col.index]) || "（空）") + "</dd></div>";
        }).join("");
        detailRow = '<tr class="row-detail"><td colspan="5"><dl class="detail-grid">' +
          '<div><dt>原始行号</dt><dd>' + item.n + "</dd></div>" +
          '<div><dt>样本状态</dt><dd>' + (excluded ? "已排除" : "保留") + "</dd></div>" +
          detailCells + "</dl></td></tr>";
      }

      return '<tr id="qa-row-' + item.n + '" class="' + (excluded ? "row-excluded " : "") +
        (state.highlight === item.n ? "is-highlight" : "") + '">' +
        '<td class="num rowno">' + item.n + "</td>" +
        '<td><span class="status-dot ' + (excluded ? "is-out" : "") + '">' + (excluded ? "已排除" : "保留") + "</span>" +
        (excluded && state.excludedNotes[item.n] ? '<div class="small muted">' + esc(state.excludedNotes[item.n]) + "</div>" : "") +
        "</td>" +
        "<td>" + issueHtml + "</td>" +
        '<td><button class="btn btn-ghost btn-xs" data-action="toggle-detail" data-n="' + item.n + '">' +
        (state.expanded[item.n] ? "收起明细" : "查看明细") + "</button></td>" +
        "<td>" + action + "</td>" +
        "</tr>" + detailRow;
    }).join("");

    var logItems = state.log.slice().reverse().slice(0, 60).map(function (entry) {
      return '<div class="log-item"><span class="log-time">' + esc(entry.ts) + "</span>" +
        '<span class="log-row">' + (entry.n ? "第 " + entry.n + " 行" : "批量") + "</span>" +
        '<span class="log-action">' + esc(entry.action === "排除" ? "排除" : entry.action === "恢复" ? "恢复" : entry.action) + "</span>" +
        '<span class="log-note">' + esc(entry.note || "") + "</span></div>";
    }).join("");

    return pageHead("03", "质量检查",
      "质检提示按行列出，帮助理解数据形态；它不等同于作弊或造假，是否排除由你判断。",
      '<button class="btn btn-secondary" data-action="go-import">字段设置</button>' +
      '<button class="btn btn-primary" data-action="go-explore">去探索</button>') +
      bannerHtml() +
      '<div class="kpi-grid">' +
      kpi("数据行", ST.fmtInt(state.rows.length), "原始行号保持不变", "") +
      kpi("已排除", ST.fmtInt(sc.excludedCount), "可逐条恢复", "is-warn") +
      kpi("有提示行", ST.fmtInt(summary.flaggedRows), "缺失 / 重复 / 非法 / 超范围", "") +
      kpi("无明显提示", ST.fmtInt(summary.cleanRows), "仍需结合调研情境判断", "is-accent") +
      "</div>" +
      '<div class="section"><div class="banner banner-info" style="margin:0">' +
      '<span class="banner-icon">i</span><div><strong>怎么理解这些提示：</strong>' +
      "缺失是空单元格；完全重复指在“参与比较的字段”上完全相同（ID 与被设为“忽略”的字段不参与比较，具体字段见行内提示）；非法数值是该填数字的位置出现了无法解析的文本；超范围是超出你设定的合理区间。" +
      "这些只是数据形态提示，不代表受访者作弊。默认全部保留，只有你手动排除的样本才会退出统计。" +
      "</div></div></div>" +
      '<div class="section"><div class="card">' +
      '<div class="table-toolbar">' + filterHtml +
      '<div class="spacer"></div>' +
      '<input class="search" type="search" placeholder="按行号或提示搜索" value="' + esc(state.qaQuery) + '" data-input="qa-search" data-focus-key="qa-search" aria-label="搜索质检结果">' +
      "</div>" +
      '<div class="table-toolbar">' +
      '<button class="btn btn-primary btn-sm" data-action="bulk-dedup">排除全部完全重复（保留每组首条）</button>' +
      '<button class="btn btn-secondary btn-sm" data-action="restore-all">全部恢复</button>' +
      '<span class="spacer"></span>' +
      '<span class="chip chip-muted">显示 ' + visible.length + " / " + filtered.length + " 行</span>" +
      "</div>" +
      '<div class="table-wrap is-tall"><table class="data-table">' +
      '<thead><tr><th class="num" style="width:58px">原始行号</th><th style="width:96px">状态</th><th>提示</th><th style="width:86px">明细</th><th style="width:76px">操作</th></tr></thead>' +
      "<tbody>" + (rows || '<tr><td colspan="5" style="text-align:center;padding:28px;color:var(--muted)">没有符合条件的行。</td></tr>') + "</tbody>" +
      "</table></div>" +
      (filtered.length > visible.length
        ? '<div style="text-align:center;margin-top:12px"><button class="btn btn-secondary btn-sm" data-action="qa-more">加载更多（剩余 ' +
          ST.fmtInt(filtered.length - visible.length) + " 行）</button></div>"
        : "") +
      '<div class="card-foot"><span>原始行号来自导入文件，排除后不变</span><span>统计与报告随样本实时重算</span></div>' +
      "</div></div>" +
      '<div class="section grid-2">' +
      '<div class="card"><div class="card-head"><div><h2 class="card-title">排除与恢复记录</h2>' +
      '<p class="card-sub">每次操作记录时间、原始行号与原因，按时间倒序显示。</p></div>' +
      '<span class="chip chip-muted">' + ST.fmtInt(state.log.length) + " 条</span></div>" +
      (logItems ? '<div class="log-list">' + logItems + "</div>" : '<div class="small muted">还没有排除或恢复操作。</div>') +
      (state.log.length > 60 ? '<div class="card-foot"><span>仅显示最近 60 条</span></div>' : "") +
      "</div>" +
      '<div class="card"><div class="card-head"><div><h2 class="card-title">当前样本口径</h2>' +
      '<p class="card-sub">被排除的行不会进入任何统计与报告，但仍保留在质检列表中。</p></div></div>' +
      '<div class="metric-row" style="grid-template-columns:repeat(2,minmax(0,1fr))">' +
      '<div class="metric"><div class="metric-label">原始行数</div><div class="metric-value">' + ST.fmtInt(state.rows.length) + "</div></div>" +
      '<div class="metric"><div class="metric-label">当前样本</div><div class="metric-value">' + ST.fmtInt(sc.sampleRows.length) + "</div></div>" +
      '<div class="metric"><div class="metric-label">已排除</div><div class="metric-value">' + ST.fmtInt(sc.excludedCount) + "</div></div>" +
      '<div class="metric"><div class="metric-label">排除比例</div><div class="metric-value">' + ST.pctText(sc.excludedCount, state.rows.length) + "</div></div>" +
      "</div>" +
      '<div class="small muted">排除比例过高时，结论的代表性会下降；报告会自动记录这一点。所有排除均可恢复，原始行号保持不变。</div>' +
      "</div></div>";
  }

  /* ---------------- 探索分析 ---------------- */

  function catChartItems(st, limit) {
    var max = limit || 8;
    if (st.items.length <= max) {
      return st.items.map(function (it) {
        return { label: it.label, value: it.count, suffix: ST.pctText(it.count, st.valid) };
      });
    }
    var top = st.items.slice(0, max - 1);
    var rest = st.items.slice(max - 1);
    var restCount = rest.reduce(function (a, b) { return a + b.count; }, 0);
    return top.map(function (it) {
      return { label: it.label, value: it.count, suffix: ST.pctText(it.count, st.valid) };
    }).concat([{ label: "其他（" + rest.length + " 项）", value: restCount, suffix: ST.pctText(restCount, st.valid) }]);
  }

  function fieldCard(col, rows) {
    var st = ST.statsFor(rows, col);
    var note = columnNote(col.index);
    var label = columnLabel(col);
    var head = '<div class="card-head"><div><h2 class="card-title">' + esc(label) +
      ' <span class="badge">' + typeLabel(col.type) + "</span>" +
      (label !== col.name ? ' <span class="field-orig">' + esc(col.name) + "</span>" : "") + "</h2>" +
      (note ? '<p class="card-sub">' + esc(note) + "</p>" : '<p class="card-sub">字段 #' + (col.index + 1) + "</p>") +
      "</div></div>";

    if (col.type === "cat") {
      var base = "当前样本 " + ST.fmtInt(rows.length) + " 行";
      return '<section class="card" id="field-' + col.index + '">' + head +
        metaChips(base, ST.fmtInt(st.missing), ST.fmtInt(st.valid)) +
        (st.valid
          ? '<div class="chart-scroll">' + C.hbar(catChartItems(st), {
            ariaLabel: label + "分类频数图"
          }) + "</div>"
          : '<div class="chart-empty">该字段当前没有有效回答，无法绘制频数图。</div>') +
        '<div class="card-foot"><span>百分比的分母是该字段有效回答 ' + ST.fmtInt(st.valid) + " 条</span>" +
        "<span>频数合计 " + ST.fmtInt(st.valid) + "</span></div></section>";
    }

    if (col.type === "num") {
      var base2 = "当前样本 " + ST.fmtInt(rows.length) + " 行";
      return '<section class="card" id="field-' + col.index + '">' + head +
        metaChips(base2, ST.fmtInt(st.missing), ST.fmtInt(st.valid), "非法数值 " + ST.fmtInt(st.invalid)) +
        '<div class="metric-row">' +
        '<div class="metric"><div class="metric-label">有效样本数</div><div class="metric-value">' + ST.fmtInt(st.valid) + "</div></div>" +
        '<div class="metric"><div class="metric-label">均值</div><div class="metric-value">' + ST.fmt(st.mean, 1) + "</div></div>" +
        '<div class="metric"><div class="metric-label">中位数</div><div class="metric-value">' + ST.fmt(st.median, 1) + "</div></div>" +
        "</div>" +
        '<div class="chart-scroll">' + C.histogram(st.values, { ariaLabel: label + "数值分布" }) + "</div>" +
        '<div class="card-foot"><span>范围 ' + ST.fmt(st.min, 1) + "–" + ST.fmt(st.max, 1) + "</span>" +
        "<span>缺失 " + ST.fmtInt(st.missing) + " · 非法 " + ST.fmtInt(st.invalid) + "</span></div></section>";
    }

    return '<section class="card" id="field-' + col.index + '">' + head +
      metaChips("当前样本 " + ST.fmtInt(rows.length) + " 行", ST.fmtInt(st.missing), ST.fmtInt(st.valid), "文本字段") +
      '<div class="small muted">文本字段不参与数值统计。共有 ' + ST.fmtInt(st.distinct) + " 个不同取值。</div>" +
      (st.examples.length
        ? '<ul class="small muted" style="margin:8px 0 0;padding-left:18px">' + st.examples.map(function (ex) {
          return "<li>“" + esc(ex) + "”</li>";
        }).join("") + "</ul>"
        : "") +
      "</section>";
  }

  function groupSection(rows) {
    var gi = state.group.index;
    var ti = state.group.target;
    if (gi === null || ti === null || !state.columns[gi] || !state.columns[ti]) {
      return '<div class="card"><p class="small muted" style="margin:0">当前没有可用于分组对比的分类字段。请在字段类型确认中至少保留一个分类字段。</p></div>';
    }
    if (gi === ti) {
      return '<div class="card"><p class="small muted" style="margin:0">分组字段与对比指标相同，请选择两个不同字段后再查看分组对比。</p></div>';
    }
    var res = ST.groupStats(rows, state.columns, gi, ti);
    var groupCol = state.columns[gi];
    var targetCol = state.columns[ti];
    var totalGroupRows = res.groups.reduce(function (a, g) { return a + g.n; }, 0);
    var chart;
    var table;

    if (targetCol.type === "num") {
      var items = res.groups.map(function (g) {
        return {
          label: g.name + "（n=" + g.stats.valid + "）",
          value: g.stats.mean === null ? 0 : g.stats.mean,
          suffix: "均值"
        };
      });
      chart = C.hbar(items, { ariaLabel: columnLabel(targetCol) + "分组均值对比", accent: "#0E7C72" });
      table = '<table class="report-table"><thead><tr><th>分组（' + esc(columnLabel(groupCol)) + "）</th><th class=\"num\">行数</th><th class=\"num\">有效</th><th class=\"num\">均值</th><th class=\"num\">中位数</th><th class=\"num\">缺失</th><th class=\"num\">非法</th></tr></thead><tbody>" +
        res.groups.map(function (g) {
          return "<tr><td>" + esc(g.name) + '</td><td class="num">' + g.n + '</td><td class="num">' + g.stats.valid +
            '</td><td class="num">' + ST.fmt(g.stats.mean, 1) + '</td><td class="num">' + ST.fmt(g.stats.median, 1) +
            '</td><td class="num">' + g.stats.missing + '</td><td class="num">' + g.stats.invalid + "</td></tr>";
        }).join("") + "</tbody></table>";
      return sectionWrap(groupCol, targetCol, res, totalGroupRows, chart, table, "各组均值仅基于该组有效数值，不做显著性检验。");
    }

    var aggregate = {};
    res.groups.forEach(function (g) {
      g.stats.items.forEach(function (it) {
        aggregate[it.label] = (aggregate[it.label] || 0) + it.count;
      });
    });
    var catsAll = Object.keys(aggregate).map(function (k) { return { label: k, count: aggregate[k] }; })
      .sort(function (a, b) { return b.count - a.count || a.label.localeCompare(b.label, "zh-CN"); });
    var keep = catsAll.slice(0, 6).map(function (c) { return c.label; });
    var chartCats = keep.map(function (l) { return { label: l }; });
    var hasOther = catsAll.length > keep.length;
    if (hasOther) chartCats.push({ label: "其他" });

    var chartGroups = res.groups.map(function (g) {
      var counts = {};
      var used = 0;
      keep.forEach(function (k) {
        counts[k] = g.stats.counts[k] || 0;
        used += counts[k];
      });
      if (hasOther) counts["其他"] = Math.max(0, g.stats.valid - used);
      return { name: g.name, n: g.n, stats: { valid: g.stats.valid, counts: counts } };
    });

    chart = C.stackedShare(chartGroups, chartCats, { ariaLabel: columnLabel(targetCol) + "分组构成" });
    table = '<table class="report-table"><thead><tr><th>分组（' + esc(columnLabel(groupCol)) + "）</th><th class=\"num\">有效回答</th><th class=\"num\">缺失</th><th>首位类别</th><th class=\"num\">首位占比</th></tr></thead><tbody>" +
      res.groups.map(function (g) {
        var top = g.stats.items[0];
        return "<tr><td>" + esc(g.name) + '</td><td class="num">' + ST.fmtInt(g.stats.valid) +
          '</td><td class="num">' + ST.fmtInt(g.stats.missing) + "</td><td>" +
          esc(top ? top.label : "—") + '</td><td class="num">' +
          (top ? ST.pctText(top.count, g.stats.valid) : "—") + "</td></tr>";
      }).join("") + "</tbody></table>";

    return sectionWrap(groupCol, targetCol, res, totalGroupRows, chart, table, "百分比以各分组内该字段的有效回答为分母；分组缺失 " + res.groupMissing + " 行未纳入。");
  }

  function sectionWrap(groupCol, targetCol, res, totalGroupRows, chart, table, note) {
    return '<div class="card">' +
      '<div class="card-head"><div><h2 class="card-title">分组对比 · ' + esc(columnLabel(groupCol)) + " × " + esc(columnLabel(targetCol)) + "</h2>" +
      '<p class="card-sub">分组字段：' + esc(columnLabel(groupCol)) + "（分类）　对比指标：" + esc(columnLabel(targetCol)) +
      "（" + typeLabel(targetCol.type) + "）</p></div>" +
      '<span class="chip chip-muted">分组有效行 ' + ST.fmtInt(totalGroupRows) + "</span></div>" +
      metaChips("分组有效行 " + ST.fmtInt(totalGroupRows), ST.fmtInt(res.groupMissing), ST.fmtInt(totalGroupRows)) +
      '<div class="chart-scroll">' + chart + "</div>" +
      '<div class="table-wrap" style="margin-top:12px">' + table + "</div>" +
      '<div class="card-foot"><span>' + esc(note) + "</span><span>仅描述当前样本，不外推总体</span></div></div>";
  }

  function signedDelta(value, digits) {
    if (value === null || value === undefined || !isFinite(value)) return "—";
    var zero = Math.pow(10, -digits) / 2;
    if (Math.abs(value) < zero) return "0";
    return (value > 0 ? "+" : "") + ST.fmt(value, digits);
  }

  function fixed1(value) {
    if (value === null || value === undefined || !isFinite(value)) return "—";
    return Number(value).toFixed(1);
  }

  function deltaClass(value) {
    if (value === null || value === undefined || !isFinite(value) || Math.abs(value) < 0.05) return "delta-flat";
    return value > 0 ? "delta-up" : "delta-down";
  }

  function impactCardHtml() {
    ensureCompare();
    var impact = ST.cleaningImpact(state.rows, state.columns, state.filter, state.excluded,
      state.compare.num, state.compare.cat);
    var numCol = state.compare.num !== null ? state.columns[state.compare.num] : null;
    var catCol = state.compare.cat !== null ? state.columns[state.compare.cat] : null;
    var nums = state.columns.filter(function (c) { return c.type === "num"; });
    var cats = state.columns.filter(function (c) { return c.type === "cat"; });

    var numSelect = '<select class="select" data-change="compare-num">' + nums.map(function (c) {
      return '<option value="' + c.index + '"' + (state.compare.num === c.index ? " selected" : "") + ">" + esc(columnLabel(c)) + "</option>";
    }).join("") + "</select>";
    var catSelect = '<select class="select" data-change="compare-cat">' + cats.map(function (c) {
      return '<option value="' + c.index + '"' + (state.compare.cat === c.index ? " selected" : "") + ">" + esc(columnLabel(c)) + "</option>";
    }).join("") + "</select>";

    var numBlock = "";
    if (!numCol) {
      numBlock = '<div class="chart-empty">当前没有可比较的数值字段。</div>';
    } else {
      var b = impact.num.base;
      var c = impact.num.current;
      numBlock = '<div class="impact-metrics">' +
        '<div class="impact-metric"><div class="k">有效 N</div><div class="v">' +
        (b.valid ? ST.fmtInt(b.valid) : "—") + ' <span class="impact-arrow">→</span> ' +
        (c.valid ? ST.fmtInt(c.valid) : "—") + '</div><div class="d ' + deltaClass(impact.num.validDiff) +
        '">' + signedDelta(impact.num.validDiff, 0) + "</div></div>" +
        '<div class="impact-metric"><div class="k">均值</div><div class="v">' +
        (b.valid ? fixed1(b.mean) : "—") + ' <span class="impact-arrow">→</span> ' +
        (c.valid ? fixed1(c.mean) : "—") + '</div><div class="d ' + deltaClass(impact.num.meanDiff) +
        '">' + signedDelta(impact.num.meanDiff, 1) + "</div></div>" +
        '<div class="impact-metric"><div class="k">中位数</div><div class="v">' +
        (b.valid ? fixed1(b.median) : "—") + ' <span class="impact-arrow">→</span> ' +
        (c.valid ? fixed1(c.median) : "—") + '</div><div class="d ' + deltaClass(impact.num.medianDiff) +
        '">' + signedDelta(impact.num.medianDiff, 1) + "</div></div>" +
        '<div class="impact-metric is-key"><div class="k">均值差（当前 − 基线）</div><div class="v">' +
        signedDelta(impact.num.meanDiff, 1) + '</div><div class="d">' +
        (impact.num.meanDiff === null ? "—" : "仅比较同一筛选下的行集合") + "</div></div>" +
        "</div>" +
        '<div class="evidence-note">差值按未舍入原值计算，显示值分别四舍五入。</div>';
      if (!b.valid || !c.valid) {
        numBlock += '<div class="evidence-note">' + (!b.valid ? "基线" : "当前") + "范围内没有有效数值，差值显示为 —。</div>";
      }
    }

    var catTable = "";
    if (!catCol) {
      catTable = '<div class="chart-empty">当前没有可比较的分类字段。</div>';
    } else if (!impact.cat.base.valid || !impact.cat.current.valid) {
      catTable = '<div class="chart-empty">该字段在' + (!impact.cat.base.valid ? "基线" : "当前") + "范围内没有有效回答，无法计算占比。</div>";
    } else {
      var opts = impact.cat.options.slice(0, 12);
      catTable = '<div class="table-wrap"><table class="report-table impact-table"><thead><tr><th>选项</th>' +
        '<th class="num">基线占比（n=' + impact.cat.base.valid + "）</th>" +
        '<th class="num">当前占比（n=' + impact.cat.current.valid + "）</th>" +
        '<th class="num">百分点差</th></tr></thead><tbody>' +
        opts.map(function (o) {
          return "<tr><td>" + esc(o.label) + '</td><td class="num">' +
            (o.basePct === null ? "—" : ST.fmt(o.basePct, 1) + "%") +
            '<span class="impact-count">' + o.baseCount + "/" + impact.cat.base.valid + "</span></td>" +
            '<td class="num">' + (o.currentPct === null ? "—" : ST.fmt(o.currentPct, 1) + "%") +
            '<span class="impact-count">' + o.currentCount + "/" + impact.cat.current.valid + "</span></td>" +
            '<td class="num ' + deltaClass(o.diffPp) + '">' +
            (o.diffPp === null ? "—" : signedDelta(o.diffPp, 1) + " pp") + "</td></tr>";
        }).join("") + "</tbody></table></div>" +
        (impact.cat.options.length > 12 ? '<div class="evidence-note">共 ' + impact.cat.options.length + " 个选项，仅显示前 12 项。</div>" : "") +
        '<div class="evidence-note">百分点差 = 当前占比 − 基线占比；基线占比为 0 时不做相对变化计算。</div>';
    }

    var sampleButton = "";
    if (state.source === "sample" && state.rows.length >= 9) {
      var demoCol = state.columns.filter(function (c) { return c.name === "weekly_hours" && c.type === "num"; })[0];
      if (demoCol) {
        sampleButton = '<button class="btn btn-warn btn-sm" data-action="show-row9">查看第 9 行示例（' +
          esc(columnLabel(demoCol)) + " = 168）</button>";
      }
    }

    return '<section class="card impact-card" id="impact">' +
      '<div class="impact-head"><div>' +
      '<div class="eyebrow">清洗影响 · CLEANING IMPACT</div>' +
      '<h2 class="card-title">排除样本前后，结论变了多少？</h2>' +
      '<p class="card-sub">基线 = 原始 ' + ST.fmtInt(state.rows.length) + " 行中符合当前筛选的 " +
      ST.fmtInt(impact.baselineCount) + " 行；当前 = 手动排除后同一筛选的 " +
      ST.fmtInt(impact.currentCount) + " 行。筛选变化不会被算作清洗影响。</p>" +
      '</div><div class="impact-scope">' +
      '<span class="chip chip-navy">基线 ' + ST.fmtInt(impact.baselineCount) + " 行</span>" +
      '<span class="chip chip-teal">当前 ' + ST.fmtInt(impact.currentCount) + " 行</span>" +
      '<span class="chip chip-amber">范围内排除 ' + ST.fmtInt(impact.excludedInScope) + " 行</span>" +
      '<span class="chip chip-muted">筛选：' + esc(scope().filterText) + "</span>" +
      "</div></div>" +
      '<div class="impact-controls">' +
      '<div class="filter-field"><label>数值字段</label>' + numSelect + "</div>" +
      '<div class="filter-field"><label>分类字段</label>' + catSelect + "</div>" +
      '<div class="impact-hint">' +
      (impact.excludedInScope
        ? "去除的 " + impact.excludedInScope + " 行来自当前筛选范围内的手动排除。"
        : "当前筛选范围内还没有手动排除的行；可到质量检查中排除后观察变化。") +
      "</div></div>" +
      '<div class="impact-grid">' +
      '<div class="impact-block"><h3>数值指标</h3>' + numBlock + "</div>" +
      '<div class="impact-block"><h3>分类占比</h3>' + catTable + "</div>" +
      "</div>" +
      '<div class="impact-foot"><span>清洗会改变结论：排除前请记录业务理由，所有排除均可在质量检查中撤销。</span>' +
      "<span>不提供显著性检验、置信区间或准确率。</span>" + sampleButton + "</div></section>";
  }

  function impactReportHtml(impact, isSample) {
    if (!impact) return "";
    var numCol = state.compare.num !== null ? state.columns[state.compare.num] : null;
    var catCol = state.compare.cat !== null ? state.columns[state.compare.cat] : null;
    var numRows = "";
    if (numCol && impact.num) {
      var b = impact.num.base;
      var c = impact.num.current;
      numRows = "<h3>数值字段：" + esc(columnLabel(numCol)) + "（" + esc(numCol.name) + "）</h3>" +
        '<table class="report-table"><thead><tr><th>指标</th><th class="num">基线</th><th class="num">当前</th><th class="num">差值</th></tr></thead><tbody>' +
        '<tr><td>有效 N</td><td class="num">' + (b.valid ? ST.fmtInt(b.valid) : "—") +
        '</td><td class="num">' + (c.valid ? ST.fmtInt(c.valid) : "—") +
        '</td><td class="num">' + signedDelta(impact.num.validDiff, 0) + "</td></tr>" +
        '<tr><td>均值</td><td class="num">' + (b.valid ? fixed1(b.mean) : "—") +
        '</td><td class="num">' + (c.valid ? fixed1(c.mean) : "—") +
        '</td><td class="num">' + signedDelta(impact.num.meanDiff, 1) + "</td></tr>" +
        '<tr><td>中位数</td><td class="num">' + (b.valid ? fixed1(b.median) : "—") +
        '</td><td class="num">' + (c.valid ? fixed1(c.median) : "—") +
        '</td><td class="num">' + signedDelta(impact.num.medianDiff, 1) + "</td></tr>" +
        "</tbody></table>" +
        '<p class="small muted">差值按未舍入原值计算，显示值分别四舍五入。</p>' +
        (impact.num.meanDiff === null ? '<p class="small muted">基线或当前范围没有有效数值，均值差显示为 —。</p>' : "");
    } else {
      numRows = '<p class="small muted">当前没有可比较的数值字段。</p>';
    }

    var catRows = "";
    if (catCol && impact.cat && impact.cat.base.valid && impact.cat.current.valid) {
      var opts = impact.cat.options.slice(0, 12);
      catRows = "<h3>分类字段：" + esc(columnLabel(catCol)) + "（" + esc(catCol.name) + "）</h3>" +
        '<table class="report-table"><thead><tr><th>选项</th><th class="num">基线占比（n=' +
        impact.cat.base.valid + "）</th><th class=\"num\">当前占比（n=" + impact.cat.current.valid +
        '）</th><th class="num">百分点差</th></tr></thead><tbody>' +
        opts.map(function (o) {
          return "<tr><td>" + esc(o.label) + '</td><td class="num">' +
            (o.basePct === null ? "—" : ST.fmt(o.basePct, 1) + "%") + "（" + o.baseCount + "）</td>" +
            '<td class="num">' + (o.currentPct === null ? "—" : ST.fmt(o.currentPct, 1) + "%") +
            "（" + o.currentCount + "）</td><td class=\"num\">" +
            (o.diffPp === null ? "—" : signedDelta(o.diffPp, 1) + " pp") + "</td></tr>";
        }).join("") + "</tbody></table>" +
        (impact.cat.options.length > 12 ? '<p class="small muted">共 ' + impact.cat.options.length + " 个选项，仅显示前 12 项。</p>" : "");
    } else {
      catRows = '<p class="small muted">基线或当前范围没有有效分类回答，无法计算占比。</p>';
    }

    return '<div class="report-section"><h2><span class="secno">05</span>清洗影响对比</h2>' +
      "<p><b>基线：</b>原始 " + ST.fmtInt(state.rows.length) +
      " 行在同一筛选条件下的统计；<b>当前：</b>手动排除后同一筛选条件下的统计。基线不随排除变化，筛选变化不计入清洗影响。</p>" +
      "<p><b>当前筛选：</b>" + esc(scope().filterText) +
      "。<b>基线行数：</b>" + ST.fmtInt(impact.baselineCount) +
      "；<b>当前行数：</b>" + ST.fmtInt(impact.currentCount) +
      "；<b>范围内排除：</b>" + ST.fmtInt(impact.excludedInScope) + " 行。</p>" +
      numRows + catRows +
      '<p class="small amber-text">清洗会改变结论，排除必须有业务理由并保留记录。本节仅描述同一筛选下的行集合差异，不提供显著性检验、置信区间或准确率；不自动排除任何样本。</p>' +
      (isSample ? '<p class="small muted">演示提示：内置示例第 9 行的 weekly_hours 为 168 小时/周；当前状态为“' +
        (state.excluded[9] ? "已排除" : "保留") + "”，是否排除由使用者决定。</p>" : "") +
      "</div>";
  }

  function renderExplore() {
    if (!dataReady()) {
      return pageHead("04", "探索分析", "分类频数、数值统计、分组对比与筛选，所有图表都标明分母。", "") +
        emptyState("还没有可分析的数据", "先导入 CSV 或载入示例数据，再查看统计与图表。",
          '<button class="btn btn-primary" data-action="load-sample">载入示例数据</button>' +
          '<button class="btn btn-secondary" data-action="pick-file">导入 CSV</button>');
    }

    var sc = scope();
    var cols = state.columns;
    var catCols = cols.filter(function (c) { return c.type === "cat"; });
    var numCols = cols.filter(function (c) { return c.type === "num"; });
    var textCols = cols.filter(function (c) { return c.type === "text"; });
    var ignoreCols = cols.filter(function (c) { return c.type === "ignore"; });

    var filterField = state.filter.index !== null && state.columns[state.filter.index]
      ? state.columns[state.filter.index] : null;
    var filterValues = filterField ? ST.statsFor(sc.sampleRows, filterField).items : [];

    var filterBar = '<div class="filterbar">' +
      '<div class="filter-field"><label for="filterField">筛选字段（一个分类字段）</label>' +
      '<select id="filterField" class="select" data-change="filter-field">' +
      '<option value="">不筛选</option>' +
      catCols.map(function (c) {
        return '<option value="' + c.index + '"' + (state.filter.index === c.index ? " selected" : "") + ">" + esc(columnLabel(c)) + "</option>";
      }).join("") + "</select></div>" +
      '<div class="filter-field" style="flex:1"><label>筛选取值（可多选）</label>' +
      (filterField
        ? '<div class="value-picker">' + filterValues.map(function (it) {
          return '<button class="chip-btn' + (state.filter.values.indexOf(it.label) >= 0 ? " is-on" : "") +
            '" data-action="toggle-filter-value" data-value="' + esc(it.label) + '">' + esc(it.label) + " " + it.count + "</button>";
        }).join("") + "</div>"
        : '<span class="small muted">选择字段后可勾选取值；不选等于全部。</span>') +
      "</div>" +
      '<div class="filter-summary"><span>分析范围：<b>' + ST.fmtInt(sc.rows.length) + " 行</b></span>" +
      (state.filter.values.length ? '<button class="btn btn-ghost btn-xs" data-action="clear-filter">清除筛选</button>' : "") +
      "</div></div>";

    var navChips = '<div class="chip-row" style="margin:14px 0 6px">' +
      cols.filter(function (c) { return c.type === "cat" || c.type === "num"; }).map(function (c) {
        return '<button class="chip-btn" data-action="scroll-to" data-target="field-' + c.index + '">' +
          esc(columnLabel(c)) + " · " + typeLabel(c.type) + "</button>";
      }).join("") + "</div>";

    var insights = ST.buildInsights({
      rows: sc.rows,
      columns: cols,
      totalRows: state.rows.length,
      excludedCount: sc.excludedCount,
      filterText: sc.filterText
    });

    var cards = cols.filter(function (c) { return c.type === "cat" || c.type === "num"; })
      .map(function (c) { return fieldCard(c, sc.rows); }).join("");

    var textList = textCols.map(function (c) {
      var st = ST.statsFor(sc.rows, c);
      return '<span class="chip chip-muted">' + esc(columnLabel(c)) + " · 有效 " + ST.fmtInt(st.valid) + " · 缺失 " + ST.fmtInt(st.missing) + "</span>";
    }).join("");
    var ignoreList = ignoreCols.map(function (c) {
      return '<span class="chip chip-muted">' + esc(columnLabel(c)) + (c.isId ? "（ID）" : "") + "</span>";
    }).join("");

    var groupFields = catCols.map(function (c) {
      return '<option value="' + c.index + '"' + (state.group.index === c.index ? " selected" : "") + ">" + esc(columnLabel(c)) + "</option>";
    }).join("");
    var targetOptions = cols.filter(function (c) { return c.type === "cat" || c.type === "num"; }).map(function (c) {
      return '<option value="' + c.index + '"' + (state.group.target === c.index ? " selected" : "") + ">" + esc(columnLabel(c)) + "（" + typeLabel(c.type) + "）</option>";
    }).join("");

    return pageHead("04", "探索分析",
      "一个分类字段筛选、一个分类字段分组。每张图都标明分母、缺失数与有效样本数，数字全部由程序计算。",
      '<button class="btn btn-secondary" data-action="go-quality">回到质检</button>' +
      '<button class="btn btn-primary" data-action="go-report">生成报告</button>') +
      bannerHtml() +
      filterBar +
      '<div class="section">' + impactCardHtml() + "</div>" +
      navChips +
      '<div class="section">' +
      '<div class="section-head"><h2 class="section-title">洞察与依据（' + insights.length + " 条）</h2>" +
      '<p class="section-sub">筛选或排除样本后，结论与依据同步重算</p></div>' +
      '<div class="insight-list">' + insights.map(insightCard).join("") + "</div>" +
      "</div>" +
      '<div class="section">' +
      '<div class="section-head"><h2 class="section-title">字段统计</h2>' +
      '<p class="section-sub">分类 ' + catCols.length + " 个 · 数值 " + numCols.length + " 个 · 文本 " + textCols.length + " 个</p></div>" +
      '<div class="grid-2">' + cards + "</div>" +
      "</div>" +
      '<div class="section">' +
      '<div class="section-head"><h2 class="section-title">分组对比</h2>' +
      '<p class="section-sub">选择一个分类字段分组，查看数值均值或分类构成</p></div>' +
      '<div class="filterbar" style="margin-bottom:14px">' +
      '<div class="filter-field"><label for="groupField">分组字段</label>' +
      '<select id="groupField" class="select" data-change="group-field">' + groupFields + "</select></div>" +
      '<div class="filter-field"><label for="groupTarget">对比指标</label>' +
      '<select id="groupTarget" class="select" data-change="group-target">' + targetOptions + "</select></div>" +
      '<div class="filter-summary"><span class="small muted">当前样本 ' + ST.fmtInt(sc.rows.length) + " 行</span></div>" +
      "</div>" +
      groupSection(sc.rows) +
      "</div>" +
      ((textList || ignoreList)
        ? '<div class="section"><div class="card"><div class="card-head"><div><h2 class="card-title">未参与数值统计的字段</h2>' +
          '<p class="card-sub">文本字段仅统计有效与缺失；忽略字段（含 ID）不进入任何统计。</p></div></div>' +
          '<div class="chip-row">' + textList + ignoreList + "</div></div></div>"
        : "");
  }

  /* ---------------- 报告 ---------------- */

  function buildReportModel() {
    var sc = scope();
    var cols = state.columns;
    var qa = qaAll();
    var insights = ST.buildInsights({
      rows: sc.rows,
      columns: cols,
      totalRows: state.rows.length,
      excludedCount: sc.excludedCount,
      filterText: sc.filterText
    });
    var rule = ST.buildRuleSummary({
      rows: sc.rows,
      columns: cols,
      qa: qa,
      totalRows: state.rows.length,
      excludedCount: sc.excludedCount
    });
    var group = (state.group.index !== null && state.group.target !== null)
      ? ST.groupStats(sc.rows, cols, state.group.index, state.group.target) : null;
    ensureCompare();
    var impact = ST.cleaningImpact(state.rows, cols, state.filter, state.excluded,
      state.compare.num, state.compare.cat);
    var excludedRows = state.rows.filter(function (r) { return state.excluded[r.n]; }).map(function (r) {
      return { n: r.n, note: state.excludedNotes[r.n] || "手动排除" };
    });
    return {
      sc: sc,
      qa: qa,
      summary: ST.qaSummary(qa),
      insights: insights,
      rule: rule,
      group: group,
      impact: impact,
      excludedRows: excludedRows,
      generatedAt: dateTimeNow(),
      dateSlug: dateOnly()
    };
  }

  function reportMetaLine(st, rows, extra) {
    return '<div class="meta-row"><span class="chip chip-muted">分母：当前样本 ' + ST.fmtInt(rows.length) +
      " 行</span><span class=\"chip chip-muted\">缺失：" + ST.fmtInt(st.missing) +
      '</span><span class="chip chip-teal">有效样本：' + ST.fmtInt(st.valid) + "</span>" +
      (extra ? '<span class="chip">' + extra + "</span>" : "") + "</div>";
  }

  function reportBody(model) {
    var sc = model.sc;
    var cols = state.columns;
    var catCols = cols.filter(function (c) { return c.type === "cat"; });
    var numCols = cols.filter(function (c) { return c.type === "num"; });
    var textCols = cols.filter(function (c) { return c.type === "text"; });
    var ignoreCols = cols.filter(function (c) { return c.type === "ignore"; });
    var isSample = state.source === "sample";

    var charts = cols.filter(function (c) { return c.type === "cat" || c.type === "num"; }).map(function (col) {
      var st = ST.statsFor(sc.rows, col);
      if (!st.valid) {
        return '<div class="report-section"><h2><span class="secno">03</span>' + esc(columnLabel(col)) + "</h2>" +
          '<p class="muted">当前样本中该字段没有有效回答。</p></div>';
      }
      if (col.type === "cat") {
        return '<div class="report-evidence chart-card" style="border-top:0;padding-top:0;margin-top:18px">' +
          "<h3>" + esc(columnLabel(col)) + "（分类）" + (columnLabel(col) !== col.name ? ' <span class="field-orig">' + esc(col.name) + "</span>" : "") + "</h3>" + reportMetaLine(st, sc.rows) +
          '<div class="chart-scroll">' + C.hbar(catChartItems(st), { ariaLabel: columnLabel(col) + "分类频数" }) + "</div>" +
          '<p class="small muted">百分比分母为该字段有效回答 ' + ST.fmtInt(st.valid) + " 条；" +
          "频数合计 " + ST.fmtInt(st.valid) + "。</p></div>";
      }
      return '<div class="report-evidence chart-card" style="border-top:0;padding-top:0;margin-top:18px">' +
        "<h3>" + esc(columnLabel(col)) + "（数值）" + (columnLabel(col) !== col.name ? ' <span class="field-orig">' + esc(col.name) + "</span>" : "") + "</h3>" + reportMetaLine(st, sc.rows, "非法数值 " + ST.fmtInt(st.invalid)) +
        '<div class="report-kpis" style="grid-template-columns:repeat(3,minmax(0,1fr))">' +
        '<div class="report-kpi"><div class="k">有效样本数</div><div class="v">' + ST.fmtInt(st.valid) + "</div></div>" +
        '<div class="report-kpi"><div class="k">均值</div><div class="v">' + ST.fmt(st.mean, 1) + "</div></div>" +
        '<div class="report-kpi"><div class="k">中位数</div><div class="v">' + ST.fmt(st.median, 1) + "</div></div></div>" +
        '<div class="chart-scroll">' + C.histogram(st.values, { ariaLabel: columnLabel(col) + "数值分布" }) + "</div>" +
        '<p class="small muted">范围 ' + ST.fmt(st.min, 1) + "–" + ST.fmt(st.max, 1) + "；缺失 " + ST.fmtInt(st.missing) +
        "，非法 " + ST.fmtInt(st.invalid) + " 不参与计算。</p></div>";
    }).join("");

    var groupBlock = "";
    if (model.group && model.group.groups.length) {
      var g = model.group;
      var groupCol = cols[g.groupField.index];
      var targetCol = cols[g.targetField.index];
      var chartHtml;
      var tableHtml;
      if (targetCol.type === "num") {
        chartHtml = C.hbar(g.groups.map(function (item) {
          return { label: item.name + "（n=" + item.stats.valid + "）", value: item.stats.mean || 0, suffix: "均值" };
        }), { ariaLabel: "分组均值对比" });
        tableHtml = '<table class="report-table"><thead><tr><th>分组</th><th class="num">行数</th><th class="num">有效</th><th class="num">均值</th><th class="num">中位数</th></tr></thead><tbody>' +
          g.groups.map(function (item) {
            return "<tr><td>" + esc(item.name) + '</td><td class="num">' + item.n + '</td><td class="num">' + item.stats.valid +
              '</td><td class="num">' + ST.fmt(item.stats.mean, 1) + '</td><td class="num">' + ST.fmt(item.stats.median, 1) + "</td></tr>";
          }).join("") + "</tbody></table>";
      } else {
        var agg = {};
        g.groups.forEach(function (item) {
          item.stats.items.forEach(function (it) { agg[it.label] = (agg[it.label] || 0) + it.count; });
        });
        var catsAll = Object.keys(agg).map(function (k) { return { label: k, count: agg[k] }; })
          .sort(function (a, b) { return b.count - a.count; });
        var keep = catsAll.slice(0, 6).map(function (c) { return c.label; });
        var chartCats = keep.map(function (l) { return { label: l }; });
        var hasOther = catsAll.length > keep.length;
        if (hasOther) chartCats.push({ label: "其他" });
        var chartGroups = g.groups.map(function (item) {
          var counts = {};
          var used = 0;
          keep.forEach(function (k) { counts[k] = item.stats.counts[k] || 0; used += counts[k]; });
          if (hasOther) counts["其他"] = Math.max(0, item.stats.valid - used);
          return { name: item.name, n: item.n, stats: { valid: item.stats.valid, counts: counts } };
        });
        chartHtml = C.stackedShare(chartGroups, chartCats, { ariaLabel: "分组构成对比" });
        tableHtml = '<table class="report-table"><thead><tr><th>分组</th><th class="num">有效回答</th><th class="num">缺失</th><th>首位类别</th><th class="num">首位占比</th></tr></thead><tbody>' +
          g.groups.map(function (item) {
            var top = item.stats.items[0];
            return "<tr><td>" + esc(item.name) + '</td><td class="num">' + item.stats.valid + '</td><td class="num">' +
              item.stats.missing + "</td><td>" + esc(top ? top.label : "—") + '</td><td class="num">' +
              (top ? ST.pctText(top.count, item.stats.valid) : "—") + "</td></tr>";
          }).join("") + "</tbody></table>";
      }
      groupBlock = '<div class="report-section"><h2><span class="secno">04</span>分组对比</h2>' +
        '<p>分组字段：' + esc(columnLabel(groupCol)) + "；对比指标：" + esc(columnLabel(targetCol)) +
        "（" + typeLabel(targetCol.type) + "）。分组缺失 " + g.groupMissing + " 行未纳入。百分比以各分组内有效回答为分母。</p>" +
        '<div class="chart-scroll">' + chartHtml + "</div>" + tableHtml +
        '<p class="small muted">仅描述当前样本的分组差异，未进行显著性检验，不推断总体差异或因果关系。</p></div>';
    } else {
      groupBlock = '<div class="report-section"><h2><span class="secno">04</span>分组对比</h2>' +
        '<p>当前没有可用的分组字段或对比指标。可在探索分析页设置分组字段后重新生成报告；本节不代表已完成分组检验。</p></div>';
    }

    var excludedBlock = model.excludedRows.length
      ? '<table class="report-table"><thead><tr><th class="num">原始行号</th><th>排除原因</th></tr></thead><tbody>' +
        model.excludedRows.map(function (r) {
          return '<tr><td class="num">' + r.n + "</td><td>" + esc(r.note) + "</td></tr>";
        }).join("") + "</tbody></table>"
      : '<p>当前没有排除任何样本。</p>';

    var logBlock = state.log.length
      ? '<table class="report-table"><thead><tr><th>时间</th><th>原始行号</th><th>操作</th><th>说明</th></tr></thead><tbody>' +
        state.log.slice().reverse().slice(0, 40).map(function (entry) {
          return "<tr><td>" + esc(entry.ts) + '</td><td class="num">' + (entry.n || "—") + "</td><td>" +
            esc(entry.action) + "</td><td>" + esc(entry.note || "") + "</td></tr>";
        }).join("") + "</tbody></table>" +
        (state.log.length > 40 ? '<p class="small muted">仅显示最近 40 条操作，完整记录保留在质量检查页。</p>' : "")
      : "";

    var evidenceBlocks = model.insights.map(function (ins, idx) {
      var ev = ins.evidence;
      return '<div class="report-evidence">' +
        '<div class="evidence-head">' +
        "<h3>证据 " + (idx + 1) + " · " + esc(ins.title) + "</h3>" +
        '<dl class="evidence-grid">' +
        '<div class="evidence-item"><dt>结论</dt><dd>' + esc(ins.statement) + "</dd></div>" +
        '<div class="evidence-item"><dt>字段</dt><dd>' + esc(ev.field) + "</dd></div>" +
        '<div class="evidence-item"><dt>筛选条件</dt><dd>' + esc(ev.filter) + "</dd></div>" +
        '<div class="evidence-item"><dt>计算方式</dt><dd>' + esc(ev.method) + "</dd></div>" +
        '<div class="evidence-item"><dt>分母</dt><dd>' + esc(ev.denominator) + "</dd></div>" +
        '<div class="evidence-item"><dt>分子</dt><dd>' + esc(ev.numerator) + "</dd></div>" +
        "</dl></div>" +
        '<div class="evidence-item"><dt>参与计算的原始行号（分母，共 ' + ev.rows.length + " 行）</dt><div class=\"rownum-block\">" +
        esc(ST.compressRanges(ev.rows)) + "</div></div>" +
        (ev.detailRows.length
          ? '<table class="report-table"><thead><tr><th class="num">原始行号</th>' +
            ev.detailColumns.map(function (n) { return "<th>" + esc(n) + "</th>"; }).join("") + "</tr></thead><tbody>" +
            ev.detailRows.slice(0, 40).map(function (row) {
              return '<tr><td class="num">' + row.n + "</td>" + row.values.map(function (v) {
                return "<td>" + (esc(v) || "（空）") + "</td>";
              }).join("") + "</tr>";
            }).join("") + "</tbody></table>" +
            (ev.detailRows.length > 40 ? '<p class="small muted">明细共 ' + ev.detailRows.length + " 行，报告仅列前 40 行；完整行号见上方。</p>" : "")
          : "") +
        "</div>";
    }).join("");

    var fieldTable = '<table class="report-table"><thead><tr><th>字段</th><th>类型</th><th class="num">有效</th><th class="num">缺失</th><th class="num">非法数值</th><th>说明</th></tr></thead><tbody>' +
      cols.map(function (col) {
        var st = ST.statsFor(sc.rows, col);
        var label = columnLabel(col);
        return "<tr><td>" + esc(label) + (label !== col.name ? ' <span class="field-orig">' + esc(col.name) + "</span>" : "") + (col.isId ? "（ID）" : "") + "</td><td>" + typeLabel(col.type) +
          '</td><td class="num">' + (col.type === "ignore" ? "—" : ST.fmtInt(st.valid)) +
          '</td><td class="num">' + (col.type === "ignore" ? "—" : ST.fmtInt(st.missing)) +
          '</td><td class="num">' + (col.type === "num" ? ST.fmtInt(st.invalid) : "—") + "</td><td>" +
          esc(columnNote(col.index) || (col.isId ? "仅用于定位原始行，不参与统计" : "—")) + "</td></tr>";
      }).join("") + "</tbody></table>";

    var title = displayName() + "：调研事实报告";
    var smallSample = sc.rows.length < 30;

    return '' +
      '<div class="report-head">' +
      '<div class="report-kicker">SURVEYTRACE · 调研证据报告</div>' +
      '<h1 class="report-title">' + esc(title) + "</h1>" +
      '<div class="report-meta">' +
      "<span>生成时间：<b>" + esc(model.generatedAt) + "</b></span>" +
      "<span>数据来源：<b>" + esc(isSample ? "内置合成演示数据" : state.fileName) + "</b></span>" +
      "<span>分析工具：<b>SurveyTrace 本地版</b></span>" +
      "</div>" +
      (isSample
        ? '<div class="report-badge">合成演示数据 · 不代表真实调研，仅用于展示分析流程</div>'
        : '<div class="report-badge is-real">用户本地导入的真实数据 · 本报告不含个人信息</div>') +
      (smallSample ? '<div class="report-badge">小样本提示：N=' + ST.fmtInt(sc.rows.length) + "（&lt;30），仅作个案观察，不外推总体</div>" : "") +
      "</div>" +

      '<div class="report-section"><h2><span class="secno">01</span>样本与口径</h2>' +
      "<p>本报告只描述当前分析样本，不推断总体。样本经过人工排除与筛选，具体口径如下：</p>" +
      '<div class="report-kpis">' +
      '<div class="report-kpi"><div class="k">原始记录</div><div class="v">' + ST.fmtInt(state.rows.length) + "</div></div>" +
      '<div class="report-kpi"><div class="k">已排除</div><div class="v">' + ST.fmtInt(sc.excludedCount) + "</div></div>" +
      '<div class="report-kpi"><div class="k">进入分析</div><div class="v">' + ST.fmtInt(sc.sampleRows.length) + "</div></div>" +
      '<div class="report-kpi"><div class="k">筛选后样本</div><div class="v">' + ST.fmtInt(sc.rows.length) + "</div></div>" +
      "</div>" +
      "<p><b>筛选条件：</b>" + esc(sc.filterText) + "。<b>排除比例：</b>" + ST.pctText(sc.excludedCount, state.rows.length) + "。</p>" +
      "<p><b>字段结构：</b>分类 " + catCols.length + " 个、数值 " + numCols.length + " 个、文本 " + textCols.length +
      " 个、忽略 " + ignoreCols.length + " 个。忽略字段不参与任何统计；ID 字段仅用于定位原始行，不参与均值。</p>" +
      "<p><b>质检情况：</b>缺失 " + model.summary.missingRows + " 行、完全重复 " + model.summary.duplicateRows +
      " 行、非法数值 " + model.summary.invalidRows + " 行、超出设定范围 " + model.summary.rangeRows +
      " 行。这些提示只描述数据形态，不等同于作弊；是否排除由分析者判断，并保留记录。</p>" +
      "</div>" +

      '<div class="report-section"><h2><span class="secno">02</span>事实摘要</h2>' +
      '<div class="fact-list">' + model.insights.map(function (ins, idx) {
        return '<div class="fact-item"><span class="fact-no">' + (idx + 1) + "</span>" +
          '<span class="fact-text">' + esc(ins.statement) + "</span></div>";
      }).join("") + "</div>" +
      '<p class="small muted">以上为描述性事实，均可在第 09 节“证据附录”中追溯字段、筛选条件、计算方式与原始行号。</p>' +
      "</div>" +

      '<div class="report-section"><h2><span class="secno">03</span>描述统计图表</h2>' +
      '<p>每张图表标注分母、缺失数与有效样本数。分类百分比以该字段有效回答为分母；数值统计只使用可解析的有效值。</p>' +
      charts +
      "</div>" +

      groupBlock +
      impactReportHtml(model.impact, isSample) +

      '<div class="report-section"><h2><span class="secno">06</span>排除与恢复记录</h2>' +
      excludedBlock +
      (logBlock ? "<p style=\"margin-top:12px\"><b>操作日志（最近 40 条）：</b></p>" + logBlock : "") +
      "</div>" +

      '<div class="report-section"><h2><span class="secno">07</span>规则摘要与追问建议</h2>' +
      '<p class="small amber-text">当前版本未接入任何大模型或外部模型服务。以下文字由本地规则根据统计结果生成，不是 AI 实时解读；原始问卷数据不会上传。</p>' +
      "<ul>" + model.rule.bullets.map(function (b) { return "<li>" + esc(b) + "</li>"; }).join("") + "</ul>" +
      "<p><b>建议的追问方向：</b></p><ol>" +
      model.rule.followups.map(function (f) { return "<li>" + esc(f) + "</li>"; }).join("") + "</ol></div>" +

      '<div class="report-section"><h2><span class="secno">08</span>局限说明</h2>' +
      '<ul class="limit-list">' +
      "<li>本报告只描述当前样本，不推断总体；样本并非概率抽样，无法计算抽样误差与置信区间。</li>" +
      "<li>未进行显著性检验，不提供 p 值或置信区间；观察到的组间差异可能来自抽样波动。</li>" +
      "<li>相关不等于因果：两个指标同时变化，不能据此判断影响方向或因果机制。</li>" +
      "<li>缺失值按字段单独剔除，未做插补；不同题目的分母可能不同，比例之间不宜直接相加。</li>" +
      "<li>排除记录由人工判断产生，可能引入选择性偏差；所有排除均已记录并可撤销。</li>" +
      "<li>完全重复按当前参与比较的字段判定（被忽略字段与 ID 不参与），不替代对重复提交机制的核查。</li>" +
      (isSample ? "<li>当前数据为程序合成的演示数据，不对应任何真实个人或真实调研，不能用于真实决策。</li>" : "") +
      (smallSample ? "<li>当前样本量小于 30，只能作为个案观察，不应外推总体。</li>" : "") +
      "</ul></div>" +

      '<div class="report-section"><h2><span class="secno">09</span>证据附录</h2>' +
      '<p>以下逐条列出第 02 节结论的依据。行号为原始 CSV 数据行序号（表头不计）。</p>' +
      evidenceBlocks + "</div>" +

      '<div class="report-section"><h2><span class="secno">10</span>字段口径</h2>' + fieldTable + "</div>" +

      '<div class="report-foot"><span>由 SurveyTrace 在本地浏览器生成 · 未上传任何问卷数据</span><span>生成时间 ' + esc(model.generatedAt) + " · 版本 0.3.1</span></div>";
  }

  function renderReport() {
    if (!dataReady()) {
      return pageHead("05", "报告", "生成结构化事实报告，导出 HTML 或当前样本 CSV，也可直接打印为 PDF。", "") +
        emptyState("还没有可生成报告的数据", "先导入 CSV 或载入示例数据，再生成事实报告。",
          '<button class="btn btn-primary" data-action="load-sample">载入示例数据</button>' +
          '<button class="btn btn-secondary" data-action="pick-file">导入 CSV</button>');
    }
    var model = buildReportModel();
    var small = model.sc.rows.length < 30;

    return pageHead("05", "报告",
      "报告包含样本口径、事实摘要、图表、排除记录、规则摘要、局限说明与证据附录。导出文件为静态 HTML，数字在导出时冻结。",
      '<button class="btn btn-secondary" data-action="export-csv">导出当前样本 CSV</button>' +
      '<button class="btn btn-primary" data-action="export-html">导出 HTML 报告</button>') +
      bannerHtml() +
      '<div class="report-actions">' +
      '<button class="btn btn-secondary btn-sm" data-action="print">打印 / 另存为 PDF</button>' +
      '<span class="small muted">在打印对话框中选择“另存为 PDF”，纸张建议 A4、纵向。</span>' +
      (small ? '<span class="chip chip-amber">小样本 N=' + ST.fmtInt(model.sc.rows.length) + "，不外推总体</span>" : "") +
      "</div>" +
      '<div class="report-paper">' + markCompactTables(reportBody(model)) + "</div>";
  }

  /* ---------------- 导出 ---------------- */

  var PRINT_RULES = [
    "@page{size:A4 portrait;margin:13mm}",
    "html,body{background:#fff !important}",
    "body{-webkit-print-color-adjust:exact;print-color-adjust:exact}",
    ".sidebar,.topbar,.appfoot,.page-head,.page-actions,.report-actions,.banner,.toast,.modal-backdrop,.empty,.no-print{display:none !important}",
    ".app{display:block}",
    ".main{margin:0 !important;padding:0 !important}",
    ".view{padding:0 !important;max-width:none !important}",
    ".report-paper{border:0 !important;box-shadow:none !important;margin:0 !important;padding:0 !important;max-width:none !important;background:#fff}",
    ".report-section{break-inside:auto;page-break-inside:auto;margin-top:18px}",
    ".report-head{break-after:avoid;page-break-after:avoid;margin-bottom:16px}",
    ".report-section h2,.report-section h3,.report-evidence h3{break-after:avoid;page-break-after:avoid}",
    ".chart-card{break-inside:avoid;page-break-inside:avoid}",
    ".evidence-head{break-inside:avoid;page-break-inside:avoid;break-after:avoid;page-break-after:avoid}",
    ".report-kpis,.meta-row,.report-badge,.fact-item,.report-foot{break-inside:avoid;page-break-inside:avoid}",
    ".chart-scroll{overflow:visible !important;padding-bottom:0}",
    ".chart-scroll svg,.chart{break-inside:avoid;page-break-inside:avoid;min-width:0;width:100%;height:auto}",
    ".report-table{break-inside:auto;page-break-inside:auto}",
    ".report-table thead{display:table-header-group}",
    ".report-table tr{break-inside:avoid;page-break-inside:avoid}",
    ".report-table.is-compact{break-inside:avoid;page-break-inside:avoid}",
    ".rownum-block{max-height:none;overflow:visible}",
    "details.evidence{display:none}",
    "a{color:inherit;text-decoration:none}"
  ].join("\n");

  /* 短表格（表头 + 不超过 12 行数据）整块不跨页；长表交给表头重复与行内不切断。 */
  function markCompactTables(html) {
    return String(html).replace(/<table class="report-table([^"]*)">([\s\S]*?)<\/table>/g, function (whole, cls, inner) {
      var rows = (inner.match(/<tr\b/g) || []).length;
      if (rows <= 13 && cls.indexOf("is-compact") < 0) {
        return '<table class="report-table' + cls + ' is-compact">' + inner + "</table>";
      }
      return whole;
    });
  }

  /* 运行时把打印规则注入页面，导出 HTML 复用同一份 PRINT_RULES，避免两套规则漂移。 */
  function ensurePrintStyles() {
    if (document.getElementById("print-rules")) return;
    var el = document.createElement("style");
    el.id = "print-rules";
    el.setAttribute("media", "print");
    el.textContent = PRINT_RULES;
    document.head.appendChild(el);
  }

  var REPORT_CSS = [
    ":root{--ink:#132433;--ink2:#3d5364;--muted:#6f8090;--muted2:#93a2af;--teal:#0e7c72;--teal-soft:#e4f2ef;--teal-line:#bfe0da;--amber:#b45309;--amber-soft:#fdf1dc;--amber-line:#ecd3a4;--border:#e6e0d3;--paper:#fff;--canvas:#f7f4ec}",
    "*{box-sizing:border-box}",
    "body{margin:0;background:var(--canvas);color:var(--ink);font-family:'PingFang SC','Hiragino Sans GB','Microsoft YaHei','Noto Sans SC',system-ui,sans-serif;font-size:14px;line-height:1.7;-webkit-font-smoothing:antialiased}",
    ".report-paper{background:#fff;max-width:900px;margin:28px auto;padding:46px 52px 40px;border:1px solid var(--border);box-shadow:0 18px 50px -40px rgba(19,36,51,.55)}",
    ".report-head{border-bottom:2px solid var(--ink);padding-bottom:18px;margin-bottom:24px}",
    ".report-kicker{font-size:10px;letter-spacing:.22em;color:var(--teal);font-weight:700;margin-bottom:8px}",
    ".report-title{font-size:26px;margin:0 0 8px;line-height:1.3}",
    ".report-meta{display:flex;gap:18px;flex-wrap:wrap;font-size:11.5px;color:var(--muted)}",
    ".report-meta b{color:var(--ink2);font-weight:550}",
    ".report-badge{display:inline-flex;align-items:center;gap:6px;margin:14px 8px 0 0;padding:6px 11px;border-radius:6px;background:var(--amber-soft);border:1px solid var(--amber-line);color:#7c4409;font-size:11.5px;font-weight:550}",
    ".report-badge.is-real{background:var(--teal-soft);border-color:var(--teal-line);color:#0a5f58}",
    ".report-section{margin-top:26px}",
    ".report-section h2{font-size:15px;margin:0 0 10px;padding-bottom:6px;border-bottom:1px solid var(--border);display:flex;gap:8px;align-items:baseline}",
    ".report-section h2 .secno{font-size:10px;color:var(--teal);letter-spacing:.08em}",
    ".report-section p{margin:0 0 8px;font-size:12.5px;line-height:1.85}",
    ".report-section ul,.report-section ol{margin:0 0 10px;padding-left:20px;font-size:12.5px;line-height:1.85}",
    ".report-section li{margin-bottom:5px}",
    ".fact-list{padding:0;margin:0}",
    ".fact-item{position:relative;padding:8px 10px 8px 32px;border-top:1px dashed var(--border);font-size:12.5px;line-height:1.8}",
    ".fact-item:first-child{border-top:0}",
    ".fact-no{position:absolute;left:4px;top:10px;width:18px;height:18px;border-radius:50%;background:var(--teal-soft);color:#0a5f58;font-size:10px;font-weight:700;display:grid;place-items:center}",
    ".report-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin:14px 0 4px}",
    ".report-kpi{border:1px solid var(--border);border-radius:7px;padding:9px 11px;background:#fbfaf6}",
    ".report-kpi .k{font-size:10px;color:var(--muted)}",
    ".report-kpi .v{font-size:19px;font-weight:650;font-variant-numeric:tabular-nums}",
    ".report-table{width:100%;border-collapse:collapse;font-size:11.5px;margin:8px 0 4px}",
    ".report-table th,.report-table td{border:1px solid var(--border);padding:6px 8px;text-align:left}",
    ".report-table th{background:#faf8f2;font-weight:600;color:var(--ink2)}",
    ".report-table .num{text-align:right;font-variant-numeric:tabular-nums}",
    ".meta-row{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:10px}",
    ".chip{display:inline-flex;align-items:center;gap:5px;padding:3px 9px;border-radius:999px;border:1px solid var(--border);background:#fbfaf6;color:var(--ink2);font-size:11.5px;line-height:1.6;white-space:nowrap}",
    ".chip-teal{background:var(--teal-soft);border-color:var(--teal-line);color:#0a5f58}",
    ".chip-muted{background:#f4f1e9;color:var(--muted)}",
    ".chart-scroll{overflow-x:auto;overflow-y:hidden;padding-bottom:2px}",
    ".chart{width:100%;min-width:520px;height:auto;display:block}",
    ".chart text{font-family:'PingFang SC','Microsoft YaHei',system-ui,sans-serif}",
    ".report-evidence{border-top:1px dashed var(--border);padding-top:10px;margin-top:12px}",
    ".report-evidence h3{font-size:12px;margin:0 0 6px}",
    ".evidence-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:9px 22px;margin-bottom:11px;margin-top:0}",
    ".evidence-item{font-size:11.5px;line-height:1.65}",
    ".evidence-item dt{color:var(--muted2);font-size:10.5px;letter-spacing:.04em;margin-bottom:1px}",
    ".evidence-item dd{margin:0;color:var(--ink2)}",
    ".rownum-block{font-size:11px;color:var(--ink2);background:#faf8f2;border:1px solid var(--border);border-radius:6px;padding:7px 9px;line-height:1.7;max-height:86px;overflow:auto;word-break:break-all;font-variant-numeric:tabular-nums}",
    ".limit-list{padding-left:18px}",
    ".small{font-size:11.5px}",
    ".muted{color:var(--muted)}",
    ".amber-text{color:#8a4308}",
    ".report-foot{margin-top:30px;padding-top:12px;border-top:1px solid var(--border);font-size:10.5px;color:var(--muted2);display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}",
    "@media print{" + PRINT_RULES + "}",
    "@media (max-width:760px){.report-paper{padding:24px 18px;margin:0}.report-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.report-title{font-size:21px}}"
  ].join("\n");

  function buildStandaloneReport(model) {
    return "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"utf-8\">\n" +
      "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
      "<title>" + esc(displayName()) + " · 调研事实报告</title>\n" +
      "<meta name=\"generator\" content=\"SurveyTrace 0.3.1\">\n" +
      "<style>\n" + REPORT_CSS + "\n</style>\n</head>\n<body>\n" +
      '<div class="report-paper">' + markCompactTables(reportBody(model)) + "</div>\n</body>\n</html>";
  }

  function csvCell(value) {
    var s = value === null || value === undefined ? "" : String(value);
    if (/[",\r\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function exportCsv() {
    var sc = scope();
    if (!sc.rows.length) {
      toast("当前样本为空，无法导出 CSV", true);
      return;
    }
    var lines = [];
    lines.push(["原始行号"].concat(state.columns.map(function (c) { return c.name; })).map(csvCell).join(","));
    sc.rows.forEach(function (row) {
      lines.push([row.n].concat(row.cells).map(csvCell).join(","));
    });
    var text = "\ufeff" + lines.join("\r\n") + "\r\n";
    var suffix = sc.filterText !== "无筛选" ? "-已筛选" : "";
    downloadText("SurveyTrace-当前样本" + suffix + "-" + stampNow() + ".csv", text, "text/csv;charset=utf-8");
    toast("已导出当前样本 " + ST.fmtInt(sc.rows.length) + " 行（含筛选条件）");
  }

  function exportHtml() {
    var model = buildReportModel();
    if (!model.sc.rows.length && !state.rows.length) {
      toast("还没有数据，无法生成报告", true);
      return;
    }
    var html = buildStandaloneReport(model);
    downloadText("SurveyTrace-调研事实报告-" + dateOnly() + ".html", html, "text/html;charset=utf-8");
    toast("HTML 报告已生成，请在浏览器下载中查看");
  }

  function downloadSample() {
    var sample = window.SURVEYTRACE_SAMPLE;
    if (!sample) {
      toast("示例数据未加载", true);
      return;
    }
    downloadText("SurveyTrace-示例数据-校园学习空间需求调查.csv",
      "\ufeff" + sample.csv, "text/csv;charset=utf-8");
    toast("示例 CSV 已下载（120 行，含缺失与重复记录）");
  }

  /* ---------------- 交互 ---------------- */

  function setPage(page) {
    if (!PAGE_TITLES[page]) return;
    state.page = page;
    state.highlight = null;
    save();
    render();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function updateChrome() {
    document.querySelectorAll(".nav-item").forEach(function (btn) {
      var on = btn.getAttribute("data-page") === state.page;
      btn.classList.toggle("is-active", on);
      btn.setAttribute("aria-current", on ? "page" : "false");
    });
    var topbarPage = $("#topbarPage");
    if (topbarPage) topbarPage.textContent = PAGE_TITLES[state.page] || "概览";
    var chip = $("#sourceChip");
    if (chip) {
      if (!dataReady()) {
        chip.className = "chip chip-muted";
        chip.textContent = "未载入数据";
      } else if (state.source === "sample") {
        chip.className = "chip chip-amber";
        chip.textContent = "合成演示数据 · " + state.rows.length + " 行";
      } else {
        chip.className = "chip chip-teal";
        chip.textContent = "本地数据 · " + state.rows.length + " 行";
      }
    }
    var clearBtn = $("#clearBtn");
    if (clearBtn) clearBtn.disabled = !dataReady();
  }

  function render() {
    if (!PAGE_TITLES[state.page]) state.page = "overview";
    var pages = {
      overview: renderOverview,
      import: renderImport,
      quality: renderQuality,
      explore: renderExplore,
      report: renderReport
    };
    var view = $("#view");
    view.innerHTML = pages[state.page]();
    document.body.dataset.page = state.page;
    updateChrome();
    if (state.highlight) {
      setTimeout(function () {
        var el = document.getElementById("qa-row-" + state.highlight);
        if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
      }, 60);
    }
  }

  function rerenderKeepFocus(focusKey) {
    var active = document.activeElement;
    var key = focusKey || (active && active.getAttribute && active.getAttribute("data-focus-key"));
    var pos = active && typeof active.selectionStart === "number" ? active.selectionStart : null;
    render();
    if (key) {
      var el = document.querySelector('[data-focus-key="' + key + '"]');
      if (el) {
        el.focus();
        if (pos !== null && el.setSelectionRange) {
          try { el.setSelectionRange(pos, pos); } catch (e) { /* 非文本输入忽略 */ }
        }
      }
    }
  }

  function excludeRow(n, note) {
    if (state.excluded[n]) return;
    state.excluded[n] = true;
    state.excludedNotes[n] = note || "手动排除";
    state.log.push({ ts: dateTimeNow(), n: n, action: "排除", note: note || "手动排除" });
    save();
    render();
    toast("已排除第 " + n + " 行；统计与报告已重算，可随时恢复");
  }

  function restoreRow(n) {
    if (!state.excluded[n]) return;
    var note = state.excludedNotes[n];
    delete state.excluded[n];
    delete state.excludedNotes[n];
    state.log.push({ ts: dateTimeNow(), n: n, action: "恢复", note: note ? "原排除原因：" + note : "恢复样本" });
    save();
    render();
    toast("已恢复第 " + n + " 行；统计与报告已重算");
  }

  function bulkDedup() {
    var qa = qaAll();
    var targets = qa.filter(function (item) {
      return item.duplicateOf && !state.excluded[item.n];
    }).map(function (item) {
      return { n: item.n, ref: item.duplicateOf };
    });
    if (!targets.length) {
      toast("没有需要排除的完全重复行（可能已全部排除）");
      return;
    }
    openModal({
      title: "排除 " + targets.length + " 行完全重复记录？",
      body: "每组重复记录保留最早的一行，其余 " + targets.length + " 行将从统计中排除。所有排除都写入操作日志，可逐条或一次性恢复。",
      confirmLabel: "排除重复行",
      onConfirm: function () {
        targets.forEach(function (t) {
          state.excluded[t.n] = true;
          state.excludedNotes[t.n] = "完全重复（与第 " + t.ref + " 行相同）";
          state.log.push({
            ts: dateTimeNow(),
            n: t.n,
            action: "排除",
            note: "批量排除完全重复（与第 " + t.ref + " 行相同）"
          });
        });
        save();
        render();
        toast("已排除 " + targets.length + " 行重复记录，统计已重算");
      }
    });
  }

  function restoreAll() {
    var count = Object.keys(state.excluded).length;
    if (!count) {
      toast("当前没有被排除的样本");
      return;
    }
    openModal({
      title: "恢复全部 " + count + " 行样本？",
      body: "所有排除记录将失效，但操作日志仍保留这次恢复动作。统计与报告会立即按完整样本重算。",
      confirmLabel: "全部恢复",
      onConfirm: function () {
        var rows = Object.keys(state.excluded).map(Number).sort(function (a, b) { return a - b; });
        state.excluded = {};
        state.excludedNotes = {};
        state.log.push({
          ts: dateTimeNow(),
          n: 0,
          action: "恢复",
          note: "恢复全部 " + count + " 行（原始行号：" + ST.compressRanges(rows) + "）"
        });
        save();
        render();
        toast("已恢复全部样本，统计已重算");
      }
    });
  }

  function openModal(opts) {
    var root = $("#modalRoot");
    root.innerHTML = '<div class="modal-backdrop"><div class="modal" role="dialog" aria-modal="true">' +
      "<h3>" + esc(opts.title) + "</h3><p>" + esc(opts.body) + "</p>" +
      '<div class="modal-actions"><button class="btn btn-secondary" data-action="close-modal">取消</button>' +
      '<button class="btn btn-primary" data-action="confirm-modal">' + esc(opts.confirmLabel || "确定") + "</button></div>" +
      "</div></div>";
    openModal._confirm = opts.onConfirm;
    var first = root.querySelector("button");
    if (first) first.focus();
  }

  function closeModal() {
    var root = $("#modalRoot");
    root.innerHTML = "";
    openModal._confirm = null;
  }

  function gotoRow(n) {
    var row = state.rows[n - 1];
    state.highlight = row ? n : null;
    state.page = "quality";
    state.qaFilter = "all";
    state.qaQuery = "";
    state.qaLimit = Math.max(state.qaLimit, Math.min(n + 20, 300));
    save();
    render();
  }

  function bindEvents() {
    document.addEventListener("click", function (event) {
      var target = event.target.closest("[data-action]");
      if (!target) return;
      var action = target.getAttribute("data-action");
      var n = Number(target.getAttribute("data-n"));

      if (action === "nav" || action === "go-import" || action === "go-quality" ||
          action === "go-explore" || action === "go-report") {
        event.preventDefault();
        var page = action === "nav" ? target.getAttribute("data-page") : action.replace("go-", "");
        setPage(page === "import" ? "import" : page);
        return;
      }
      if (action === "pick-file") {
        var input = $("#fileInput");
        if (input) input.click();
        return;
      }
      if (action === "load-sample") { loadSample(true); return; }
      if (action === "download-sample") { downloadSample(); return; }
      if (action === "clear-data") {
        if (!dataReady()) return;
        openModal({
          title: "清空当前数据？",
          body: "将删除当前数据集、字段设置、排除记录与操作日志。此操作不可撤销，但你可以重新导入或载入示例。",
          confirmLabel: "确认清空",
          onConfirm: function () { clearDataset(); }
        });
        return;
      }
      if (action === "exclude-row") {
        excludeRow(n, target.getAttribute("data-note") || "手动排除");
        return;
      }
      if (action === "restore-row") { restoreRow(n); return; }
      if (action === "toggle-detail") {
        state.expanded[n] = !state.expanded[n];
        render();
        return;
      }
      if (action === "bulk-dedup") { bulkDedup(); return; }
      if (action === "restore-all") { restoreAll(); return; }
      if (action === "qa-filter") {
        state.qaFilter = target.getAttribute("data-filter");
        state.qaLimit = 60;
        save();
        render();
        return;
      }
      if (action === "qa-more") {
        state.qaLimit += 60;
        render();
        return;
      }
      if (action === "goto-row") { gotoRow(n); return; }
      if (action === "show-row9") {
        gotoRow(9);
        toast("已定位到第 9 行；未做任何排除，是否排除由你决定");
        return;
      }
      if (action === "toggle-filter-value") {
        var value = target.getAttribute("data-value");
        var idx = state.filter.values.indexOf(value);
        if (idx >= 0) state.filter.values.splice(idx, 1);
        else state.filter.values.push(value);
        save();
        render();
        return;
      }
      if (action === "clear-filter") {
        state.filter.values = [];
        save();
        render();
        return;
      }
      if (action === "scroll-to") {
        var id = target.getAttribute("data-target");
        var el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
        return;
      }
      if (action === "export-html") { exportHtml(); return; }
      if (action === "export-csv") { exportCsv(); return; }
      if (action === "print") { window.print(); return; }
      if (action === "close-modal") { closeModal(); return; }
      if (action === "confirm-modal") {
        var fn = openModal._confirm;
        closeModal();
        if (fn) fn();
        return;
      }
    });

    document.addEventListener("change", function (event) {
      var el = event.target;
      var action = el.getAttribute && el.getAttribute("data-change");
      if (!action) return;

      if (action === "set-type") {
        var i = Number(el.getAttribute("data-index"));
        var col = state.columns[i];
        if (!col || col.isId) return;
        col.type = el.value;
        if (state.filter.index === i && col.type !== "cat") {
          state.filter = { index: null, values: [] };
        }
        if (state.group.index === i && col.type !== "cat") {
          state.group.index = null;
        }
        if (state.group.target === i && col.type !== "cat" && col.type !== "num") {
          state.group.target = null;
        }
        if (state.group.index === state.group.target) {
          state.group.target = null;
        }
        var cat = state.columns.filter(function (c) { return c.type === "cat"; })[0];
        var num = state.columns.filter(function (c) { return c.type === "num"; })[0];
        if (state.group.index === null || !state.columns[state.group.index] ||
            state.columns[state.group.index].type !== "cat") {
          state.group.index = cat ? cat.index : null;
        }
        if (state.group.target === null || !state.columns[state.group.target] ||
            (state.columns[state.group.target].type !== "cat" && state.columns[state.group.target].type !== "num") ||
            state.group.target === state.group.index) {
          var other = state.columns.filter(function (c) {
            return (c.type === "num" || c.type === "cat") && c.index !== state.group.index;
          })[0];
          state.group.target = other ? other.index : null;
        }
        save();
        render();
        toast("字段类型已更新，统计与报告已重算");
        return;
      }

      if (action === "range-min" || action === "range-max") {
        var idx = Number(el.getAttribute("data-index"));
        var range = state.ranges[idx] || { min: null, max: null };
        var val = el.value === "" ? null : Number(el.value);
        if (val !== null && !isFinite(val)) val = null;
        if (action === "range-min") range.min = val;
        else range.max = val;
        if (range.min === null && range.max === null) delete state.ranges[idx];
        else state.ranges[idx] = range;
        save();
        render();
        toast("合理范围已更新，质检已重算");
        return;
      }

      if (action === "filter-field") {
        var value = el.value;
        state.filter.index = value === "" ? null : Number(value);
        state.filter.values = [];
        save();
        render();
        return;
      }

      if (action === "group-field") {
        state.group.index = el.value === "" ? null : Number(el.value);
        if (state.group.index === state.group.target) {
          var alt = state.columns.filter(function (c) {
            return (c.type === "num" || c.type === "cat") && c.index !== state.group.index;
          })[0];
          state.group.target = alt ? alt.index : null;
        }
        save();
        render();
        return;
      }

      if (action === "group-target") {
        state.group.target = el.value === "" ? null : Number(el.value);
        save();
        render();
        return;
      }

      if (action === "compare-num") {
        ensureCompare();
        state.compare.num = el.value === "" ? null : Number(el.value);
        save();
        render();
        return;
      }

      if (action === "compare-cat") {
        ensureCompare();
        state.compare.cat = el.value === "" ? null : Number(el.value);
        save();
        render();
        return;
      }
    });

    var searchTimer = null;
    document.addEventListener("input", function (event) {
      var el = event.target;
      if (!el.getAttribute || el.getAttribute("data-input") !== "qa-search") return;
      state.qaQuery = el.value;
      state.qaLimit = 60;
      clearTimeout(searchTimer);
      searchTimer = setTimeout(function () {
        save();
        rerenderKeepFocus("qa-search");
      }, 260);
    });

    var fileInput = $("#fileInput");
    if (fileInput) {
      fileInput.addEventListener("change", function () {
        if (fileInput.files && fileInput.files[0]) {
          var file = fileInput.files[0];
          fileInput.value = "";
          handleFile(file);
        }
      });
    }

    document.addEventListener("dragover", function (event) {
      var dz = event.target.closest && event.target.closest("#dropzone");
      if (!dz) return;
      event.preventDefault();
      dz.classList.add("is-drag");
    });
    document.addEventListener("dragleave", function (event) {
      var dz = event.target.closest && event.target.closest("#dropzone");
      if (dz) dz.classList.remove("is-drag");
    });
    document.addEventListener("drop", function (event) {
      var dz = event.target.closest && event.target.closest("#dropzone");
      if (!dz) return;
      event.preventDefault();
      dz.classList.remove("is-drag");
      if (event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files[0]) {
        handleFile(event.dataTransfer.files[0]);
      }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeModal();
    });
  }

  /* 内置示例的中文标签/说明/合理区间只影响展示与本机提示，不改写 CSV 原始表头。
     浏览器里可能残留旧版本状态，启动时按列名重新套用一次，保证旧状态也能显示中文标签。 */
  function refreshSampleMeta() {
    var meta = window.SURVEYTRACE_SAMPLE;
    if (state.source !== "sample" || !meta || !state.columns) return;
    (meta.columns || []).forEach(function (m) {
      var col = null;
      state.columns.forEach(function (c) { if (c.name === m.name) col = c; });
      if (!col) return;
      if (m.label) col.label = m.label;
      if (m.note) state.columnNotes[col.index] = m.note;
      if (m.range) state.ranges[col.index] = { min: m.range.min, max: m.range.max };
    });
  }

  function boot() {
    ensurePrintStyles();
    restore();
    refreshSampleMeta();
    bindEvents();
    render();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();