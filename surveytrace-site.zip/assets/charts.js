/* SurveyTrace 图表：纯 SVG，无第三方依赖。所有数值由调用方计算后传入。 */
(function (global) {
  "use strict";

  var ST = global.ST;

  function esc(value) {
    return String(value === null || value === undefined ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function shortLabel(label, max) {
    var s = String(label);
    if (s.length <= max) return s;
    return s.slice(0, max - 1) + "…";
  }

  var PALETTE = ["#0E7C72", "#2F9188", "#5FAFA6", "#8FC8C0", "#C2DED8", "#B45309", "#94A3B8", "#64748B"];

  /* 水平条形图：频数 + 百分比 */
  function hbar(items, opts) {
    opts = opts || {};
    var W = opts.width || 760;
    var labelW = opts.labelW || 170;
    var valueW = opts.valueW || 118;
    var plotW = W - labelW - valueW;
    var barH = opts.barH || 24;
    var gap = opts.gap || 12;
    var top = 10;
    var H = top + items.length * (barH + gap) + 4;
    var max = 1;
    items.forEach(function (it) { if (it.value > max) max = it.value; });

    var grid = "";
    [0.25, 0.5, 0.75, 1].forEach(function (r) {
      var x = labelW + plotW * r;
      grid += '<line x1="' + x + '" y1="' + top + '" x2="' + x + '" y2="' + (H - 6) +
        '" stroke="#EDE7DA" stroke-width="1" stroke-dasharray="3 4"/>';
    });

    var body = items.map(function (it, i) {
      var y = top + i * (barH + gap);
      var w = Math.max(2, (it.value / max) * plotW);
      var fill = i === 0 ? (opts.accent || "#0E7C72") : "#9BCDC6";
      var suffix = it.suffix ? " · " + it.suffix : "";
      return '' +
        '<g><title>' + esc(it.label) + '：' + esc(ST.fmtInt(it.value)) + esc(suffix) + '</title>' +
        '<text x="' + (labelW - 12) + '" y="' + (y + barH / 2 + 4) + '" text-anchor="end" font-size="12.5" fill="#3D5364">' +
        esc(shortLabel(it.label, 13)) + '</text>' +
        '<rect x="' + labelW + '" y="' + y + '" width="' + plotW + '" height="' + barH + '" rx="5" fill="#F3EFE6"/>' +
        '<rect x="' + labelW + '" y="' + y + '" width="' + w.toFixed(1) + '" height="' + barH + '" rx="5" fill="' + fill + '"/>' +
        '<text x="' + (labelW + w + 10).toFixed(1) + '" y="' + (y + barH / 2 + 4) + '" font-size="12" font-weight="600" fill="#132433">' +
        esc(ST.fmtInt(it.value)) + esc(suffix) + '</text></g>';
    }).join("");

    return '<svg class="chart" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="' +
      esc(opts.ariaLabel || "分类频数图") + '" preserveAspectRatio="xMinYMin meet">' + grid + body + "</svg>";
  }

  /* 直方图：数值分布 */
  function histogram(values, opts) {
    opts = opts || {};
    var W = opts.width || 760;
    var H = opts.height || 232;
    var m = { l: 46, r: 12, t: 16, b: 42 };
    var plotW = W - m.l - m.r;
    var plotH = H - m.t - m.b;
    if (!values.length) {
      return '<div class="chart-empty">没有可绘制的有效数值。</div>';
    }

    var min = Math.min.apply(null, values);
    var max = Math.max.apply(null, values);
    var integerOnly = values.every(function (v) { return Math.abs(v - Math.round(v)) < 1e-9; });
    var bins = [];
    var i;

    if (integerOnly && max - min <= 12) {
      for (i = Math.floor(min); i <= Math.ceil(max); i++) {
        bins.push({ from: i, to: i, count: 0, label: String(i) });
      }
      values.forEach(function (v) {
        var b = bins[v - Math.floor(min)];
        if (b) b.count++;
      });
    } else {
      var nBins = opts.bins || 8;
      var span = max - min || 1;
      var step = span / nBins;
      for (i = 0; i < nBins; i++) {
        var from = min + step * i;
        var to = i === nBins - 1 ? max : min + step * (i + 1);
        bins.push({ from: from, to: to, count: 0, label: ST.fmt(from, 1) + "–" + ST.fmt(to, 1) });
      }
      values.forEach(function (v) {
        var idx = Math.min(nBins - 1, Math.floor((v - min) / step));
        if (idx < 0) idx = 0;
        bins[idx].count++;
      });
    }

    var maxCount = 1;
    bins.forEach(function (b) { if (b.count > maxCount) maxCount = b.count; });
    var gap = bins.length > 8 ? 4 : 6;
    var barW = Math.max(6, plotW / bins.length - gap);
    var baseY = m.t + plotH;

    var ticks = "";
    for (var t = 0; t <= 4; t++) {
      var y = baseY - (plotH * t) / 4;
      var val = Math.round((maxCount * t) / 4);
      ticks += '<line x1="' + m.l + '" y1="' + y.toFixed(1) + '" x2="' + (W - m.r) + '" y2="' + y.toFixed(1) +
        '" stroke="#EDE7DA" stroke-width="1" stroke-dasharray="' + (t === 0 ? "0" : "3 4") + '"/>' +
        '<text x="' + (m.l - 10) + '" y="' + (y + 4).toFixed(1) + '" text-anchor="end" font-size="11" fill="#7A8A97">' + val + "</text>";
    }

    var bars = bins.map(function (b, idx) {
      var h = b.count ? Math.max(3, (b.count / maxCount) * plotH) : 0;
      var x = m.l + idx * (barW + gap);
      var y = baseY - h;
      return '<g><title>' + esc(b.label) + '：' + b.count + ' 个</title>' +
        '<rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + barW.toFixed(1) + '" height="' + h.toFixed(1) +
        '" rx="3" fill="#0E7C72" opacity="' + (0.96 - idx * 0.03 > 0.6 ? (0.96 - idx * 0.03).toFixed(2) : 0.6) + '"/></g>';
    }).join("");

    var labels = "";
    var labelEvery = bins.length > 10 ? Math.ceil(bins.length / 6) : 1;
    bins.forEach(function (b, idx) {
      if (idx % labelEvery !== 0 && idx !== bins.length - 1) return;
      var x = m.l + idx * (barW + gap) + barW / 2;
      labels += '<text x="' + x.toFixed(1) + '" y="' + (baseY + 20) + '" text-anchor="middle" font-size="11" fill="#7A8A97">' +
        esc(shortLabel(b.label, 10)) + "</text>";
    });

    return '<svg class="chart" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="' +
      esc(opts.ariaLabel || "数值分布直方图") + '" preserveAspectRatio="xMinYMin meet">' + ticks + bars + labels +
      '<line x1="' + m.l + '" y1="' + baseY + '" x2="' + (W - m.r) + '" y2="' + baseY + '" stroke="#D8D0BF" stroke-width="1"/></svg>';
  }

  /* 100% 堆叠对比：一个分类字段在分组内的构成 */
  function stackedShare(groups, categories, opts) {
    opts = opts || {};
    var W = opts.width || 760;
    var labelW = opts.labelW || 150;
    var plotW = W - labelW - 16;
    var rowH = 26;
    var gap = 12;
    var top = 34;
    var H = top + groups.length * (rowH + gap) + 6;
    var legend = "";
    var lx = 0;
    categories.forEach(function (cat, i) {
      legend += '<rect x="' + lx + '" y="2" width="10" height="10" rx="2" fill="' + PALETTE[i % PALETTE.length] + '"/>' +
        '<text x="' + (lx + 15) + '" y="11" font-size="11" fill="#41566A">' + esc(shortLabel(cat.label, 8)) + "</text>";
      lx += 26 + Math.min(88, cat.label.length * 12);
    });

    var rows = groups.map(function (g, gi) {
      var y = top + gi * (rowH + gap);
      var total = g.stats.valid || 0;
      var cursor = labelW;
      var segs = "";
      categories.forEach(function (cat, ci) {
        var count = g.stats.counts[cat.label] || 0;
        var width = total ? (count / total) * plotW : 0;
        if (!width) return;
        var color = PALETTE[ci % PALETTE.length];
        segs += '<rect x="' + cursor.toFixed(1) + '" y="' + y + '" width="' + width.toFixed(1) + '" height="' + rowH +
          '" fill="' + color + '"><title>' + esc(g.name) + ' · ' + esc(cat.label) + "：" + count + " 条（" +
          ST.pctText(count, total) + '）</title></rect>';
        if (width > 38) {
          segs += '<text x="' + (cursor + width / 2).toFixed(1) + '" y="' + (y + rowH / 2 + 4) +
            '" text-anchor="middle" font-size="10.5" fill="#FFFFFF" font-weight="600">' + ST.fmt((count / total) * 100, 0) + "%</text>";
        }
        cursor += width;
      });
      return '<g><text x="' + (labelW - 10) + '" y="' + (y + rowH / 2 + 4) + '" text-anchor="end" font-size="12" fill="#3D5364">' +
        esc(shortLabel(g.name, 9)) + '</text>' +
        '<text x="' + (labelW - 10) + '" y="' + (y + rowH / 2 + 17) + '" text-anchor="end" font-size="10" fill="#93A2AF">n=' + g.stats.valid + "</text>" +
        '<rect x="' + labelW + '" y="' + y + '" width="' + plotW + '" height="' + rowH + '" rx="4" fill="#F3EFE6"/>' +
        segs + "</g>";
    }).join("");

    return '<svg class="chart" viewBox="0 0 ' + W + " " + H + '" role="img" aria-label="' +
      esc(opts.ariaLabel || "分组构成对比图") + '" preserveAspectRatio="xMinYMin meet">' + legend + rows + "</svg>";
  }

  global.STCharts = { hbar: hbar, histogram: histogram, stackedShare: stackedShare, esc: esc, PALETTE: PALETTE };
})(window);