/* SurveyTrace 核心计算：CSV 解析、字段推断、统计、质检、洞察与证据。
   所有数字均由本文件按当前数据实时计算，不含任何硬编码统计结果。 */
(function (global) {
  "use strict";

  var LIMITS = { maxRows: 3000, maxCols: 40, maxBytes: 5 * 1024 * 1024 };
  var NUMBER_RE = /^[+-]?(?:\d+(?:\.\d+)?|\.\d+)(?:[eE][+-]?\d+)?$/;

  /* ---------------- 文本与编码 ---------------- */

  function norm(value) {
    if (value === null || value === undefined) return "";
    return String(value).replace(/\u00a0/g, " ").trim();
  }

  function decodeBuffer(buffer) {
    var bytes = new Uint8Array(buffer);
    var bom = "";
    var encoding = "UTF-8";
    var text = "";

    if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
      bom = "UTF-8 BOM";
      text = new TextDecoder("utf-8").decode(bytes.subarray(3));
    } else if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) {
      bom = "UTF-16LE BOM";
      encoding = "UTF-16LE";
      text = new TextDecoder("utf-16le").decode(bytes.subarray(2));
    } else if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
      bom = "UTF-16BE BOM";
      encoding = "UTF-16BE";
      text = new TextDecoder("utf-16be").decode(bytes.subarray(2));
    } else {
      try {
        text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
        encoding = "UTF-8";
      } catch (errUtf8) {
        try {
          text = new TextDecoder("gb18030").decode(bytes);
          encoding = "GB18030";
        } catch (errGbk) {
          throw new Error("无法识别文件编码：不是有效的 UTF-8，也无法按 GB18030 解码。请用记事本或表格软件另存为 UTF-8 编码的 CSV 后重试。");
        }
      }
    }

    return { text: text, encoding: encoding, bom: bom, bytes: bytes.length };
  }

  function isBlankLine(text) {
    return /^\s*$/.test(text);
  }

  function CSVError(message, line) {
    var err = new Error(message);
    err.name = "CSVParseError";
    err.line = line || 0;
    return err;
  }

  function detectDelimiter(text) {
    var sample = text.slice(0, 20000);
    var best = { char: ",", count: 0, name: "逗号" };
    var candidates = [
      { char: ",", name: "逗号" },
      { char: ";", name: "分号" },
      { char: "\t", name: "制表符" }
    ];
    // 只统计引号外、首个逻辑行内的分隔符
    candidates.forEach(function (item) {
      var count = 0;
      var inQuotes = false;
      for (var i = 0; i < sample.length; i++) {
        var ch = sample[i];
        if (ch === '"') {
          if (inQuotes && sample[i + 1] === '"') { i++; continue; }
          inQuotes = !inQuotes;
        } else if (!inQuotes && ch === item.char) {
          count++;
        } else if (!inQuotes && (ch === "\n" || ch === "\r")) {
          break;
        }
      }
      if (count > best.count) best = { char: item.char, count: count, name: item.name };
    });
    return best;
  }

  /* 表头去重：先保留唯一的原始列名，再给重复项分配未被占用的 _2、_3… 后缀。
     这样 A,A,A_2 会得到 A, A_3, A_2，而不是出现两个 A_2。 */
  function dedupeHeaders(headerCells) {
    var baseNames = headerCells.map(function (name, idx) {
      return name || "字段" + (idx + 1);
    });
    var counts = Object.create(null);
    baseNames.forEach(function (name) {
      counts[name] = (counts[name] || 0) + 1;
    });

    var used = Object.create(null);
    var result = new Array(baseNames.length);

    baseNames.forEach(function (name, idx) {
      if (counts[name] === 1) {
        result[idx] = name;
        used[name] = true;
      }
    });

    baseNames.forEach(function (name, idx) {
      if (result[idx]) return;
      var candidate = name;
      if (used[candidate]) {
        var seq = 2;
        while (used[name + "_" + seq]) seq++;
        candidate = name + "_" + seq;
      }
      result[idx] = candidate;
      used[candidate] = true;
    });

    return result;
  }

  /* ---------------- CSV 解析 ---------------- */

  function parseCSV(text, options) {
    options = options || {};
    var maxRows = options.maxRows || LIMITS.maxRows;
    var maxCols = options.maxCols || LIMITS.maxCols;
    var source = String(text || "").replace(/^\uFEFF/, "");

    if (!source.trim()) {
      throw CSVError("文件内容为空，没有找到表头与数据行。", 0);
    }

    var delimiter = detectDelimiter(source);
    var records = [];
    var record = [];
    var field = "";
    var inQuotes = false;
    var afterQuote = false;
    var line = 1;
    var recordStart = 1;

    for (var i = 0; i < source.length; i++) {
      var ch = source[i];

      if (inQuotes) {
        if (ch === '"') {
          if (source[i + 1] === '"') {
            field += '"';
            i++;
          } else {
            inQuotes = false;
            afterQuote = true;
          }
        } else {
          if (ch === "\n") line++;
          field += ch;
        }
        continue;
      }

      if (afterQuote) {
        if (ch === delimiter.char) {
          record.push(field);
          field = "";
          afterQuote = false;
        } else if (ch === "\n" || ch === "\r") {
          if (ch === "\r" && source[i + 1] === "\n") i++;
          record.push(field);
          records.push({ cells: record, line: recordStart });
          record = [];
          field = "";
          afterQuote = false;
          line++;
          recordStart = line;
        } else if (ch === " " || ch === "\t") {
          // 明确允许：闭合引号后的空格/制表符被忽略，字段值仍按 trim 处理
        } else {
          throw CSVError(
            "第 " + line + " 行的引号闭合后出现非法字符“" + ch + "”。引号字段结束后只能接分隔符、换行或文件结束；空格与制表符允许但会被忽略。",
            line
          );
        }
        continue;
      }

      if (ch === '"') {
        if (field.trim() !== "") {
          throw CSVError("第 " + line + " 行的引号位置不合法：引号前只能有空格，并且必须位于字段开头。", line);
        }
        inQuotes = true;
        field = "";
      } else if (ch === delimiter.char) {
        record.push(field);
        field = "";
      } else if (ch === "\n" || ch === "\r") {
        if (ch === "\r" && source[i + 1] === "\n") i++;
        record.push(field);
        records.push({ cells: record, line: recordStart });
        record = [];
        field = "";
        line++;
        recordStart = line;
      } else {
        field += ch;
      }
    }

    if (inQuotes) {
      throw CSVError("文件结尾仍有未闭合的引号（从第 " + recordStart + " 行开始）。请检查该行字段中的英文双引号是否成对。", recordStart);
    }

    if (field !== "" || record.length || afterQuote) {
      record.push(field);
      records.push({ cells: record, line: recordStart });
    }

    var useful = records.filter(function (rec) {
      return !(rec.cells.length === 1 && isBlankLine(rec.cells[0]));
    });

    if (!useful.length) {
      throw CSVError("文件中只有空行，没有可用的表头。", 1);
    }

    var headerCells = useful[0].cells.map(function (cell) { return norm(cell); });
    if (headerCells.length > maxCols) {
      throw CSVError("表头共有 " + headerCells.length + " 列，超过上限 " + maxCols + " 列。请先在表格软件中删减列后再导入。", 1);
    }

    var header = dedupeHeaders(headerCells);

    var dataRecords = useful.slice(1);
    if (!dataRecords.length) {
      throw CSVError("只找到表头，没有数据行。请确认文件是否完整导出。", 1);
    }
    if (dataRecords.length > maxRows) {
      throw CSVError("文件包含 " + dataRecords.length + " 行数据，超过上限 " + maxRows + " 行。请先拆分或抽样后再导入。", 2);
    }

    var rows = [];
    dataRecords.forEach(function (rec, idx) {
      if (rec.cells.length !== header.length) {
        throw CSVError(
          "第 " + (idx + 1) + " 条数据（文件第 " + rec.line + " 行）有 " + rec.cells.length +
          " 个字段，但表头是 " + header.length + " 列。常见原因：字段中的逗号没有用英文引号包起来，或引号没有成对闭合。",
          rec.line
        );
      }
      rows.push({ n: idx + 1, cells: rec.cells.map(function (cell) { return norm(cell); }) });
    });

    return {
      header: header,
      rows: rows,
      delimiter: delimiter.char,
      delimiterName: delimiter.name,
      skippedBlankLines: records.length - useful.length,
      totalLines: records.length
    };
  }

  /* ---------------- 数值解析 ---------------- */

  function parseNumber(raw) {
    if (raw === null || raw === undefined) return null;
    var s = String(raw).trim();
    if (!s) return null;
    s = s.replace(/[０-９]/g, function (ch) {
      return String.fromCharCode(ch.charCodeAt(0) - 0xfee0);
    })
      .replace(/．/g, ".")
      .replace(/－/g, "-")
      .replace(/＋/g, "+");

    if (/^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, "");
    if (!NUMBER_RE.test(s)) return null;
    var n = Number(s);
    return isFinite(n) ? n : null;
  }

  var ID_NAME_RE = /^(id|编号|序号|no\.?|respondent_?id|student_?id|样本编号|受访者编号|用户编号)$/i;
  var TEXT_NAME_RE = /(备注|说明|意见|建议|反馈|评论|理由|开放|comment|note|feedback|remark|open_?ended)/i;

  function isIdName(name) {
    var s = norm(name);
    return ID_NAME_RE.test(s) || /(^|_)id$/i.test(s) || /编号$/.test(s);
  }

  function colLabel(col) {
    if (!col) return "";
    return col.label ? col.label : col.name;
  }

  function columnHeading(col) {
    var label = colLabel(col);
    if (!col) return "";
    return label && label !== col.name ? label + "（" + col.name + "）" : col.name;
  }

  function fieldWithSource(col, typeText) {
    var label = colLabel(col);
    var source = label && label !== col.name
      ? "（" + col.name + "，" + typeText + "）"
      : "（" + typeText + "）";
    return label + source;
  }

  function inferColumns(header, rows) {
    return header.map(function (name, index) {
      var values = [];
      rows.forEach(function (row) {
        var v = row.cells[index];
        if (norm(v) !== "") values.push(norm(v));
      });

      var numeric = 0;
      values.forEach(function (v) { if (parseNumber(v) !== null) numeric++; });
      var unique = Object.create(null);
      var lengths = [];
      values.forEach(function (v) {
        unique[v] = (unique[v] || 0) + 1;
        lengths.push(v.length);
      });
      var uniqueCount = Object.keys(unique).length;
      var numericRatio = values.length ? numeric / values.length : 0;
      var sortedLen = lengths.slice().sort(function (a, b) { return a - b; });
      var medianLen = sortedLen.length ? sortedLen[Math.floor(sortedLen.length / 2)] : 0;

      var type = "text";
      if (isIdName(name)) {
        type = "ignore";
      } else if (values.length && numericRatio >= 0.9 && uniqueCount >= 2) {
        type = "num";
      } else if (TEXT_NAME_RE.test(name) || medianLen > 10 || uniqueCount > 20 ||
                 (values.length && uniqueCount / values.length >= 0.65)) {
        type = "text";
      } else if (uniqueCount <= 12 || (values.length && uniqueCount / values.length <= 0.3)) {
        type = "cat";
      }

      return {
        index: index,
        key: "c" + index,
        name: name,
        type: type,
        isId: isIdName(name),
        uniqueCount: uniqueCount,
        missingCount: rows.length - values.length,
        sampleValues: values.slice(0, 3)
      };
    });
  }

  /* ---------------- 格式化 ---------------- */

  function fmt(n, digits) {
    if (n === null || n === undefined || !isFinite(n)) return "—";
    var d = digits === undefined ? 1 : digits;
    var fixed = Number(n).toFixed(d);
    var trimmed = fixed.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
    var num = Number(trimmed);
    return num.toLocaleString("zh-CN", { maximumFractionDigits: d });
  }

  function fmtInt(n) {
    if (n === null || n === undefined || !isFinite(n)) return "—";
    return Number(n).toLocaleString("zh-CN", { maximumFractionDigits: 0 });
  }

  function pct(count, base) {
    if (!base) return 0;
    return (count / base) * 100;
  }

  function pctText(count, base) {
    return fmt(pct(count, base), 1) + "%";
  }

  function medianOf(values) {
    if (!values.length) return null;
    var sorted = values.slice().sort(function (a, b) { return a - b; });
    var mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  }

  function quantile(sorted, q) {
    if (!sorted.length) return null;
    var pos = (sorted.length - 1) * q;
    var base = Math.floor(pos);
    var rest = pos - base;
    if (sorted[base + 1] !== undefined) {
      return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
    }
    return sorted[base];
  }

  /* ---------------- 字段统计 ---------------- */

  function statsFor(rows, column) {
    var missing = 0;
    var invalid = 0;
    var counts = Object.create(null);
    var order = [];
    var numbers = [];
    var examples = [];
    var distinct = Object.create(null);

    rows.forEach(function (row) {
      var raw = row.cells[column.index];
      if (norm(raw) === "") {
        missing++;
        return;
      }
      if (column.type === "num") {
        var v = parseNumber(raw);
        if (v === null) {
          invalid++;
        } else {
          numbers.push(v);
        }
      } else {
        var key = norm(raw);
        if (!counts[key]) {
          counts[key] = 0;
          order.push(key);
        }
        counts[key]++;
        if (examples.length < 3 && !distinct[key]) {
          distinct[key] = true;
          examples.push(key);
        }
      }
    });

    if (column.type === "cat") {
      var valid = 0;
      var items = order.map(function (label) {
        valid += counts[label];
        return { label: label, count: counts[label] };
      });
      items.sort(function (a, b) { return b.count - a.count || a.label.localeCompare(b.label, "zh-CN"); });
      return {
        type: "cat",
        valid: valid,
        missing: missing,
        invalid: 0,
        counts: counts,
        items: items,
        distinct: items.length,
        examples: examples
      };
    }

    if (column.type === "num") {
      var sorted = numbers.slice().sort(function (a, b) { return a - b; });
      return {
        type: "num",
        valid: numbers.length,
        missing: missing,
        invalid: invalid,
        mean: numbers.length ? numbers.reduce(function (a, b) { return a + b; }, 0) / numbers.length : null,
        median: medianOf(numbers),
        min: sorted.length ? sorted[0] : null,
        max: sorted.length ? sorted[sorted.length - 1] : null,
        q1: quantile(sorted, 0.25),
        q3: quantile(sorted, 0.75),
        values: numbers,
        distinct: Object.keys(numbers.reduce(function (acc, v) { acc[v] = 1; return acc; }, {})).length
      };
    }

    var textDistinct = Object.keys(counts).length;
    return {
      type: column.type,
      valid: rows.length - missing,
      missing: missing,
      invalid: 0,
      distinct: textDistinct,
      examples: examples
    };
  }

  function groupStats(rows, columns, groupIndex, targetIndex) {
    var groupCol = columns[groupIndex];
    var targetCol = columns[targetIndex];
    var groups = [];
    var index = Object.create(null);

    rows.forEach(function (row) {
      var g = norm(row.cells[groupIndex]);
      if (g === "") return;
      if (!index[g]) {
        index[g] = { name: g, rows: [] };
        groups.push(index[g]);
      }
      index[g].rows.push(row);
    });

    groups.sort(function (a, b) { return b.rows.length - a.rows.length || a.name.localeCompare(b.name, "zh-CN"); });

    var output = groups.map(function (group) {
      var st = statsFor(group.rows, targetCol);
      return {
        name: group.name,
        n: group.rows.length,
        stats: st
      };
    });

    var groupMissing = 0;
    rows.forEach(function (row) { if (norm(row.cells[groupIndex]) === "") groupMissing++; });

    return {
      groups: output,
      groupField: groupCol,
      targetField: targetCol,
      groupMissing: groupMissing,
      total: rows.length
    };
  }

  /* ---------------- 质检 ---------------- */

  function signatureOf(row, columns) {
    return columns
      .filter(function (c) { return c.type !== "ignore" && !c.isId; })
      .map(function (c) { return norm(row.cells[c.index]); })
      .join("\u0001");
  }

  function buildQA(rows, columns, ranges) {
    ranges = ranges || {};
    var comparable = columns.filter(function (c) { return c.type !== "ignore" && !c.isId; });
    var ignoredNonId = columns.filter(function (c) { return c.type === "ignore" && !c.isId; });
    var hasIdColumn = columns.some(function (c) { return c.isId; });

    var firstBySignature = Object.create(null);
    var duplicateOf = Object.create(null);
    rows.forEach(function (row) {
      var sig = signatureOf(row, columns);
      if (sig.replace(/\u0001/g, "") === "") return;
      if (firstBySignature[sig]) {
        duplicateOf[row.n] = firstBySignature[sig];
      } else {
        firstBySignature[sig] = row.n;
      }
    });

    var extremes = Object.create(null);
    columns.forEach(function (col) {
      if (col.type !== "num") return;
      var st = statsFor(rows, col);
      if (!st.values.length) return;
      var sorted = st.values.slice().sort(function (a, b) { return a - b; });
      var iqr = (st.q3 || 0) - (st.q1 || 0);
      if (iqr <= 0) return;
      extremes[col.index] = {
        low: st.q1 - 3 * iqr,
        high: st.q3 + 3 * iqr
      };
    });

    var results = [];
    rows.forEach(function (row) {
      var issues = [];
      var missingNames = [];
      columns.forEach(function (col) {
        if (col.type === "ignore" || col.isId) return;
        if (norm(row.cells[col.index]) === "") missingNames.push(colLabel(col));
      });
      if (missingNames.length) {
        issues.push({
          kind: "missing",
          text: "缺失 " + missingNames.length + " 个字段：" + missingNames.join("、"),
          fields: missingNames
        });
      }

      if (duplicateOf[row.n]) {
        var refRow = duplicateOf[row.n];
        var dupText;
        if (!ignoredNonId.length) {
          dupText = hasIdColumn
            ? "与第 " + refRow + " 行完全重复（除 ID 外所有字段相同）"
            : "与第 " + refRow + " 行完全重复（所有字段相同）";
        } else {
          dupText = "与第 " + refRow + " 行在参与比较的 " + comparable.length + " 个字段上完全相同（已忽略：" +
            ignoredNonId.map(colLabel).join("、") +
            (hasIdColumn ? "；ID 不参与比较" : "") + "）";
        }
        issues.push({
          kind: "duplicate",
          text: dupText,
          ref: refRow
        });
      }

      columns.forEach(function (col) {
        if (col.type !== "num") return;
        var raw = norm(row.cells[col.index]);
        var value = parseNumber(raw);
        var range = ranges[col.index];
        var hasRange = range && (range.min !== null && range.min !== undefined || range.max !== null && range.max !== undefined);

        if (raw !== "" && value === null) {
          issues.push({
            kind: "invalid",
            text: colLabel(col) + " 的值“" + raw + "”不是合法数值",
            field: colLabel(col)
          });
          return;
        }
        if (value === null) return;

        if (hasRange) {
          var belowMin = range.min !== null && range.min !== undefined && value < range.min;
          var aboveMax = range.max !== null && range.max !== undefined && value > range.max;
          if (belowMin || aboveMax) {
            var bounds = "[" + (range.min === null || range.min === undefined ? "不限" : range.min) + ", " +
              (range.max === null || range.max === undefined ? "不限" : range.max) + "]";
            issues.push({
              kind: "range",
              text: colLabel(col) + " = " + fmt(value, 2) + "，超出设定合理范围 " + bounds,
              field: colLabel(col)
            });
            return;
          }
        }

        var ex = extremes[col.index];
        if (ex && (value < ex.low || value > ex.high)) {
          issues.push({
            kind: "extreme",
            text: colLabel(col) + " = " + fmt(value, 2) + "，位于 3×IQR 之外（极端值，仅提示）",
            field: colLabel(col)
          });
        }
      });

      var hasWarn = issues.some(function (it) {
        return it.kind === "missing" || it.kind === "duplicate" || it.kind === "invalid";
      });
      var hasHint = issues.some(function (it) {
        return it.kind === "range" || it.kind === "extreme";
      });

      results.push({
        n: row.n,
        issues: issues,
        hasWarn: hasWarn,
        hasHint: hasHint,
        duplicateOf: duplicateOf[row.n] || null,
        missingCount: missingNames.length
      });
    });

    return results;
  }

  function qaSummary(qa) {
    var summary = {
      missingRows: 0,
      duplicateRows: 0,
      invalidRows: 0,
      rangeRows: 0,
      cleanRows: 0,
      flaggedRows: 0
    };
    qa.forEach(function (item) {
      var missing = false;
      var duplicate = false;
      var invalid = false;
      var range = false;
      item.issues.forEach(function (it) {
        if (it.kind === "missing") missing = true;
        if (it.kind === "duplicate") duplicate = true;
        if (it.kind === "invalid") invalid = true;
        if (it.kind === "range" || it.kind === "extreme") range = true;
      });
      if (missing) summary.missingRows++;
      if (duplicate) summary.duplicateRows++;
      if (invalid) summary.invalidRows++;
      if (range) summary.rangeRows++;
      if (!item.issues.length) summary.cleanRows++;
      if (item.issues.length) summary.flaggedRows++;
    });
    return summary;
  }

  function compressRanges(numbers) {
    if (!numbers.length) return "无";
    var sorted = numbers.slice().sort(function (a, b) { return a - b; });
    var parts = [];
    var start = sorted[0];
    var prev = sorted[0];
    for (var i = 1; i <= sorted.length; i++) {
      var cur = sorted[i];
      if (cur !== prev + 1) {
        parts.push(start === prev ? String(start) : start + "–" + prev);
        start = cur;
      }
      prev = cur;
    }
    return parts.join("、");
  }

  /* ---------------- 洞察与证据 ---------------- */

  function buildInsights(ctx) {
    var rows = ctx.rows || [];
    var columns = ctx.columns || [];
    var insights = [];

    insights.push({
      id: "sample-scope",
      kicker: "样本",
      title: "样本口径",
      statement: rows.length
        ? "当前纳入统计的样本为 " + fmtInt(rows.length) + " 行，原始数据 " + fmtInt(ctx.totalRows) +
          " 行，已排除 " + fmtInt(ctx.excludedCount) + " 行。"
        : "当前没有纳入统计的样本。",
      evidence: {
        field: "全部参与分析的字段",
        filter: ctx.filterText || "无筛选",
        method: "计数：统计未排除、且符合筛选条件的原始数据行数。",
        denominator: "原始数据 " + fmtInt(ctx.totalRows) + " 行",
        numerator: "当前样本 " + fmtInt(rows.length) + " 行",
        rows: rows.map(function (r) { return r.n; }),
        numeratorRows: rows.map(function (r) { return r.n; }),
        detailColumns: [],
        detailRows: []
      }
    });

    var active = columns.filter(function (c) { return c.type === "cat" || c.type === "num"; });
    var cats = active.filter(function (c) { return c.type === "cat"; });
    var nums = active.filter(function (c) { return c.type === "num"; });

    function addCatInsight(col) {
      var st = statsFor(rows, col);
      if (!st.valid || !st.items.length) {
        insights.push({
          id: "cat-" + col.index,
          kicker: "分类",
          title: colLabel(col),
          statement: "「" + colLabel(col) + "」在当前样本中没有有效回答，无法形成占比结论。",
          evidence: {
            field: fieldWithSource(col, "分类字段"),
            filter: ctx.filterText || "无筛选",
            method: "计数与百分比：有效回答数 ÷ 该字段有效回答总数。",
            denominator: "该字段有效回答 0 条",
            numerator: "0 条",
            rows: [],
            numeratorRows: [],
            detailColumns: [columnHeading(col)],
            detailRows: []
          }
        });
        return;
      }
      var top = st.items[0];
      var denomRows = [];
      var numRows = [];
      rows.forEach(function (row) {
        var v = norm(row.cells[col.index]);
        if (v === "") return;
        denomRows.push(row);
        if (v === top.label) numRows.push(row);
      });

      insights.push({
        id: "cat-" + col.index,
        kicker: "分类",
        title: colLabel(col),
        statement: "在「" + colLabel(col) + "」的有效回答中，「" + top.label + "」出现 " + fmtInt(top.count) +
          " 次，占 " + pctText(top.count, st.valid) + "（n=" + fmtInt(st.valid) + "，缺失 " + fmtInt(st.missing) + "）。",
        evidence: {
          field: fieldWithSource(col, "分类字段"),
          filter: ctx.filterText || "无筛选",
          method: "计数与百分比：该取值条数 ÷ 该字段非空且未排除的回答条数 × 100%。",
          denominator: "该字段有效回答 " + fmtInt(st.valid) + " 条（缺失 " + fmtInt(st.missing) + " 条不参与）",
          numerator: "「" + top.label + "」" + fmtInt(top.count) + " 条",
          rows: denomRows.map(function (r) { return r.n; }),
          numeratorRows: numRows.map(function (r) { return r.n; }),
          detailColumns: [columnHeading(col)],
          detailRows: denomRows.map(function (r) {
            return { n: r.n, values: [norm(r.cells[col.index])] };
          })
        }
      });
    }

    function addNumInsight(col) {
      var st = statsFor(rows, col);
      if (!st.valid) {
        insights.push({
          id: "num-" + col.index,
          kicker: "数值",
          title: colLabel(col),
          statement: "「" + colLabel(col) + "」没有可计算的有效数值（缺失 " + fmtInt(st.missing) + "，非法 " + fmtInt(st.invalid) + "）。",
          evidence: {
            field: fieldWithSource(col, "数值字段"),
            filter: ctx.filterText || "无筛选",
            method: "均值与中位数，仅使用可解析为数字的有效值。",
            denominator: "0 个有效数值",
            numerator: "无",
            rows: [],
            numeratorRows: [],
            detailColumns: [columnHeading(col)],
            detailRows: []
          }
        });
        return;
      }
      var validRows = [];
      rows.forEach(function (row) {
        if (parseNumber(row.cells[col.index]) !== null) validRows.push(row);
      });

      insights.push({
        id: "num-" + col.index,
        kicker: "数值",
        title: colLabel(col),
        statement: "「" + colLabel(col) + "」的有效样本为 " + fmtInt(st.valid) + " 个，均值 " + fmt(st.mean, 1) +
          "，中位数 " + fmt(st.median, 1) + "（缺失 " + fmtInt(st.missing) + "，非法数值 " + fmtInt(st.invalid) + "）。",
        evidence: {
          field: fieldWithSource(col, "数值字段"),
          filter: ctx.filterText || "无筛选",
          method: "均值 = 有效数值之和 ÷ 有效数值个数；中位数 = 有效数值排序后的中间值（偶数个取中间两数均值）。缺失与非法数值不参与计算。",
          denominator: "该字段有效数值 " + fmtInt(st.valid) + " 个（缺失 " + fmtInt(st.missing) + "，非法 " + fmtInt(st.invalid) + "）",
          numerator: "有效数值之和 " + fmt(st.mean * st.valid, 2) + "；排序中间位置",
          rows: validRows.map(function (r) { return r.n; }),
          numeratorRows: validRows.map(function (r) { return r.n; }),
          detailColumns: [columnHeading(col)],
          detailRows: validRows.map(function (r) {
            return { n: r.n, values: [norm(r.cells[col.index])] };
          })
        }
      });
    }

    var max = 6;
    for (var i = 0; i < Math.max(cats.length, nums.length) && insights.length < max; i++) {
      if (i < cats.length && insights.length < max) addCatInsight(cats[i]);
      if (i < nums.length && insights.length < max) addNumInsight(nums[i]);
    }

    return insights;
  }

  /* ---------------- 规则摘要（非模型） ---------------- */

  function buildRuleSummary(ctx) {
    var rows = ctx.rows || [];
    var columns = ctx.columns || [];
    var qa = ctx.qa || [];
    var summary = qaSummary(qa);
    var bullets = [];

    if (!rows.length) {
      return {
        bullets: ["当前没有可用样本，规则摘要暂不生成。"],
        followups: ["先导入数据或载入示例数据，再查看摘要。"],
        missingTop: null
      };
    }

    bullets.push("当前分析样本 " + fmtInt(rows.length) + " 行，占原始数据 " + fmtInt(ctx.totalRows) +
      " 行的 " + pctText(rows.length, ctx.totalRows) + "；已排除 " + fmtInt(ctx.excludedCount) + " 行。");

    var catWithData = columns.filter(function (c) { return c.type === "cat"; }).map(function (c) {
      return { col: c, st: statsFor(rows, c) };
    }).filter(function (item) { return item.st.valid > 0; });

    if (catWithData.length) {
      var best = null;
      catWithData.forEach(function (item) {
        var top = item.st.items[0];
        if (!best || pct(top.count, item.st.valid) > best.share) {
          best = { item: item, top: top, share: pct(top.count, item.st.valid) };
        }
      });
      bullets.push("占比最高的分类结论：「" + colLabel(best.item.col) + "」中「" + best.top.label + "」占 " +
        pctText(best.top.count, best.item.st.valid) + "（" + fmtInt(best.top.count) + "/" + fmtInt(best.item.st.valid) + "）。");
    }

    var numWithData = columns.filter(function (c) { return c.type === "num"; }).map(function (c) {
      return { col: c, st: statsFor(rows, c) };
    }).filter(function (item) { return item.st.valid > 0; });

    if (numWithData.length) {
      var first = numWithData[0];
      bullets.push("「" + colLabel(first.col) + "」有效样本 " + fmtInt(first.st.valid) + " 个，均值 " +
        fmt(first.st.mean, 1) + "，中位数 " + fmt(first.st.median, 1) + "，范围 " +
        fmt(first.st.min, 1) + "–" + fmt(first.st.max, 1) + "。");
    }

    var missingField = null;
    columns.forEach(function (c) {
      if (c.type === "ignore") return;
      var st = statsFor(rows, c);
      if (!missingField || st.missing > missingField.st.missing) missingField = { col: c, st: st };
    });
    if (missingField && missingField.st.missing > 0) {
      bullets.push("缺失最多的字段是「" + colLabel(missingField.col) + "」，共 " + fmtInt(missingField.st.missing) +
        " 条缺失；比例计算会自动使用该字段的有效回答作分母。");
    }

    if (summary.duplicateRows) {
      var dupComparable = columns.filter(function (c) { return c.type !== "ignore" && !c.isId; });
      var dupIgnored = columns.filter(function (c) { return c.type === "ignore" && !c.isId; });
      var dupHasId = columns.some(function (c) { return c.isId; });
      var dupScope = dupIgnored.length
        ? "在参与比较的 " + dupComparable.length + " 个字段上完全相同（未计入：" + dupIgnored.map(colLabel).join("、") +
          (dupHasId ? "；ID 不参与比较" : "") + "）"
        : (dupHasId ? "除 ID 外所有字段完全相同" : "所有字段完全相同");
      bullets.push("检出 " + fmtInt(summary.duplicateRows) + " 行" + dupScope +
        "的重复记录，是否排除由使用者判断，排除后可撤销。");
    }

    if (rows.length < 30) {
      bullets.push("注意：当前样本量小于 30，只能作为个案观察，不能外推总体。");
    }

    var followups = [];
    followups.push("若想比较不同群体（如年级、院系）的差异，请先确认每个群体至少有 30 条有效回答，并说明抽样方式。");
    followups.push("若关注两个指标是否同步变化，当前数据只能描述同时出现的比例，不能据此判断因果或显著性。");
    if (missingField && missingField.st.missing > 0) {
      followups.push("「" + colLabel(missingField.col) + "」缺失较多，建议回看问卷题号设置或补访，再判断结论是否稳定。");
    }
    followups.push("若要把结论用于正式决策，建议补充概率抽样、样本量计算与预先登记的检验方案。");

    return { bullets: bullets, followups: followups, missingTop: missingField };
  }

  /* ---------------- 清洗影响对比 ---------------- */

  function filterRows(rows, columns, filter) {
    if (!filter || filter.index === null || filter.index === undefined ||
        !filter.values || !filter.values.length) {
      return rows.slice();
    }
    var col = columns[filter.index];
    if (!col) return rows.slice();
    var set = Object.create(null);
    filter.values.forEach(function (v) { set[norm(v)] = true; });
    return rows.filter(function (row) {
      return !!set[norm(row.cells[filter.index])];
    });
  }

  /* 基线：全部原始行在同一筛选条件下；当前：手动排除后再应用同一筛选。
     只比较行集合差异，不把筛选变化计入清洗影响。 */
  function cleaningImpact(allRows, columns, filter, excluded, numIndex, catIndex) {
    var baselineRows = filterRows(allRows, columns, filter);
    var currentRows = baselineRows.filter(function (row) {
      return !excluded || !excluded[row.n];
    });

    var numCol = numIndex === null || numIndex === undefined ? null : columns[numIndex];
    var catCol = catIndex === null || catIndex === undefined ? null : columns[catIndex];
    // 字段类型可能在使用过程中被改过（如分类改为文本），对比卡只接受匹配类型，避免无意义或崩溃的比较
    if (numCol && numCol.type !== "num") numCol = null;
    if (catCol && catCol.type !== "cat") catCol = null;

    var numBase = numCol ? statsFor(baselineRows, numCol) : null;
    var numCurrent = numCol ? statsFor(currentRows, numCol) : null;
    var catBase = catCol ? statsFor(baselineRows, catCol) : null;
    var catCurrent = catCol ? statsFor(currentRows, catCol) : null;

    var validDiff = null;
    var meanDiff = null;
    var medianDiff = null;
    if (numBase && numCurrent) {
      validDiff = numCurrent.valid - numBase.valid;
      if (numBase.valid && numCurrent.valid) {
        meanDiff = numCurrent.mean - numBase.mean;
        medianDiff = numCurrent.median - numBase.median;
      }
    }

    var options = [];
    if (catBase && catCurrent) {
      var seen = Object.create(null);
      var labels = [];
      [catBase, catCurrent].forEach(function (st) {
        st.items.forEach(function (item) {
          if (!seen[item.label]) {
            seen[item.label] = true;
            labels.push(item.label);
          }
        });
      });
      labels.sort(function (a, b) {
        var ac = (catBase.counts[a] || 0) + (catCurrent.counts[a] || 0);
        var bc = (catBase.counts[b] || 0) + (catCurrent.counts[b] || 0);
        return bc - ac || a.localeCompare(b, "zh-CN");
      });
      options = labels.map(function (label) {
        var baseCount = catBase.counts[label] || 0;
        var currentCount = catCurrent.counts[label] || 0;
        var basePct = catBase.valid ? pct(baseCount, catBase.valid) : null;
        var currentPct = catCurrent.valid ? pct(currentCount, catCurrent.valid) : null;
        return {
          label: label,
          baseCount: baseCount,
          currentCount: currentCount,
          basePct: basePct,
          currentPct: currentPct,
          diffPp: basePct !== null && currentPct !== null ? currentPct - basePct : null
        };
      });
    }

    return {
      baselineCount: baselineRows.length,
      currentCount: currentRows.length,
      excludedInScope: baselineRows.length - currentRows.length,
      num: numCol ? {
        column: numCol,
        base: numBase,
        current: numCurrent,
        validDiff: validDiff,
        meanDiff: meanDiff,
        medianDiff: medianDiff
      } : null,
      cat: catCol ? {
        column: catCol,
        base: catBase,
        current: catCurrent,
        options: options
      } : null
    };
  }

  var api = {
    LIMITS: LIMITS,
    dedupeHeaders: dedupeHeaders,
    colLabel: colLabel,
    columnHeading: columnHeading,
    filterRows: filterRows,
    cleaningImpact: cleaningImpact,
    norm: norm,
    decodeBuffer: decodeBuffer,
    parseCSV: parseCSV,
    detectDelimiter: detectDelimiter,
    parseNumber: parseNumber,
    inferColumns: inferColumns,
    isIdName: isIdName,
    fmt: fmt,
    fmtInt: fmtInt,
    pct: pct,
    pctText: pctText,
    medianOf: medianOf,
    statsFor: statsFor,
    groupStats: groupStats,
    buildQA: buildQA,
    qaSummary: qaSummary,
    compressRanges: compressRanges,
    buildInsights: buildInsights,
    buildRuleSummary: buildRuleSummary,
    signatureOf: signatureOf
  };

  if (typeof module !== "undefined" && module.exports) module.exports = api;
  global.ST = api;
})(typeof window !== "undefined" ? window : globalThis);